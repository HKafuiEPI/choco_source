/*
** EPITECH PROJECT, 2024
** main.c
** File description:
** for testing
*/

#include "my.h"

void main_display(char **word)
{
    int *ab = find_biggest_square(word, 0, 0);
    char **map = replace_biggest_square(word, ab);

    for (int i = 0; map[i] != NULL; i++) {
        write(1, map[i], my_strlen(map[i]));
        write(1, "\n", 1);
    }
}

int main(int argc, char **argv)
{
    char *fd;
    char **word;
    int *ab;
    char **map;

    if (error_cases(argc, argv) == 84) {
        return 84;
    }
    if (argc == 2) {
        fd = fs_open_file(argv[1]);
        word = my_str_to_word_array(fd);
        main_display(word);
    }
    if (argc == 3) {
        word = generator(argv[2], my_getnbr(argv[1]));
        main_display(word);
    }
}
