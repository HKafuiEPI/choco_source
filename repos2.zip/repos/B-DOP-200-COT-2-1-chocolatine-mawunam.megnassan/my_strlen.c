/*
** EPITECH PROJECT, 2023
** strlen.c
** File description:
** strlen
*/

#include "my.h"

int my_strlen(char const *str)
{
    int a = 0;

    for (a = 0; str[a] != '\0'; a++);
    return a;
}
