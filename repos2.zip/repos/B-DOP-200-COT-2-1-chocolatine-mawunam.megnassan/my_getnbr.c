/*
** EPITECH PROJECT, 2024
** my_getnbr.c
** File description:
** getnbr
*/

#include "my.h"

int my_getnbr(char *str)
{
    int n = 0;
    int i = 0;
    int neg = 1;

    while (str[i] == '+' || str[i] == '-') {
        if (str[i] == '-')
            neg = neg * -1;
        i = i + 1;
    }
    while (str[i] != '\0') {
        if (str[i] >= '0' && str[i] <= '9') {
            n = n * 10;
            n = n + str[i] - '0';
            i = i + 1;
        } else
            return (n * neg);
    }
    return (n * neg);
}
