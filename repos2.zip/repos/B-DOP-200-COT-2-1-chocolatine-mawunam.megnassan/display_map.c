/*
** EPITECH PROJECT, 2023
** display_map.c
** File description:
** for map show
*/

#include "my.h"

int count_line(char const *filepath)
{
    int count = 0;
    int i = 0;

    for (i = 0; filepath[i] != '\0'; i++) {
        if (filepath[i] == '\n')
            count++;
    }
    return count + 1;
}

char *fs_open_file(char const *filepath)
{
    struct stat st;
    int return_read = 0;
    int size;
    int fd;
    char *buf = NULL;

    stat(filepath, &st);
    size = st.st_size;
    fd = open(filepath, O_RDONLY);
    if (fd < 0)
        return NULL;
    stat(filepath, &st);
    buf = malloc(sizeof(char) * size + 1);
    return_read = read(fd, buf, size);
    if (return_read == -1)
        return NULL;
    buf[size + 1] = '\0';
    close(fd);
    return buf;
}

char **allocation(int a, int b)
{
    char **map = malloc(sizeof(char *) * (b + 1));

    for (int i = 0; i < b; i++) {
        map[i] = malloc(sizeof(char) * a);
    }
    return map;
}

char **my_str_to_word_array(char *str)
{
    int a = my_strlen(str);
    int b = count_line(str);
    int line = 0;
    int col = 0;
    int j = 0;
    char **word = allocation(a, b);

    for (j = 0; str[j - 1] != '\n'; j++);
    for (int k = j; str[k] != '\0'; k++) {
        if (str[k] == '\n') {
            line++;
            col = 0;
        } else {
            word[line][col] = str[k];
            col++;
        }
    }
    word[line] = NULL;
    return word;
}

char **open_map(char **argv)
{
    char *fd = fs_open_file(argv[1]);
    char **word = my_str_to_word_array(fd);

    return word;
}
