/*
** EPITECH PROJECT, 2024
** generator.c
** File description:
** generator
*/

#include "my.h"

char **generator(char *str, int nbr)
{
    int i = 0;
    int j = 0;
    int k = 0;
    char **map = malloc(sizeof(char *) * (nbr + 1));

    for (int a = 0; a < nbr; a++) {
        map[a] = malloc(sizeof(char) * (nbr + 1));
    }
    for (i = 0; i < nbr; i++) {
        for (j = 0; j < nbr; j++) {
            map[i][j] = str[k];
            k++;
            k = str[k] == '\0' ? 0 : k;
        }
        map[i][j] = '\0';
    }
    map[nbr] = NULL;
    return map;
}
