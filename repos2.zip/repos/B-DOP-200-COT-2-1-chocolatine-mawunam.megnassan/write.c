/*
** EPITECH PROJECT, 2024
** function.c
** File description:
** bsq
*/

#include "my.h"

char **replace_biggest_square(char **map, int *info)
{
    int row = info[1];
    int col = info[2];
    int sq = info[0];

    for (int i = row; i < row + sq; i++) {
        for (int j = col; j < col + sq; j++) {
            map[i][j] = 'x';
        }
    }
    return map;
}
