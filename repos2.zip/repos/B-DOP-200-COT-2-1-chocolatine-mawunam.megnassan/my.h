/*
** EPITECH PROJECT, 2023
** my.h
** File description:
** my.h
*/

#ifndef MY_H
    #define MY_H
    #include <unistd.h>
    #include <stdlib.h>
    #include <stdio.h>
    #include <fcntl.h>
    #include <sys/stat.h>

int my_strlen(char const *str);
void my_putchar(char c);
int find_biggest_in_one(char **map, int row, int col, int sq);
int my_putstr(char const *str);
char *fs_open_file(char const *filepath);
char **my_str_to_word_array(char *str);
char **open_map(char **argv);
char **generator(char *str, int nbr);
int check_other_symbols(char *str);
int check_number(char *str);
int check_arguments(char *str);
int error_cases(int argc, char **argv);
char **replace_biggest_square(char **map, int *info);
int count_line(char const *filepath);
char **allocation(int a, int b);
int find_square_condition(char **map, int i, int col, int sq);
int find_square(char **map, int row, int col, int sq);
int *find_biggest_square(char **map, int i, int j);
int my_getnbr(char *str);

#endif
