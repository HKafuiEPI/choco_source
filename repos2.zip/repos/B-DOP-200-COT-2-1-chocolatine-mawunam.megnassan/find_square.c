/*
** EPITECH PROJECT, 2024
** find_square
** File description:
** to find square
*/

#include "my.h"

int find_square_condition(char **map, int i, int col, int sq)
{
    int j = 0;

    for (j = col; j < col + sq; j++) {
        if (map[i][j] != '.')
            return 0;
        }
}

int find_square(char **map, int row, int col, int sq)
{
    int i = 0;
    int j = 0;
    int r = find_square_condition(map, i, col, sq);
    int y = 0;

    for (i = row; i < row + sq && map[i] != NULL; i++) {
        y = find_square_condition(map, i, col, sq);
        if (y == 0)
            return 0;
    }
    if (i != (row + sq))
        return 0;
    return 1;
}

int find_biggest_in_one(char **map, int row, int col, int sq)
{
    int i = find_square(map, row, col, sq);

    for (; i == 1; sq++) {
        i = find_square(map, row, col, sq);
    }
    return (sq - 2);
}

void cond(char **map, int i, int sq, int *info)
{
    int j = 0;
    int a = 0;

    for (j = 0; map[i][j] != '\0'; j++) {
        a = find_biggest_in_one(map, i, j, sq);
        if (a > info[0]) {
            info[0] = a;
            info[1] = i;
            info[2] = j;
            sq = a + 1;
        }
    }
}

int *find_biggest_square(char **map, int i, int j)
{
    int a = 0;
    int max = 0;
    int sq = 1;
    int *info = malloc(sizeof(int) * 3);

    info[0] = 0;
    info[1] = 0;
    info[2] = 0;
    for (i = 0; map[i] != NULL; i++) {
        cond(map, i, sq, info);
    }
    return info;
}
