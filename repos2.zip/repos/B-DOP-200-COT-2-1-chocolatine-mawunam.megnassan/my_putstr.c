/*
** EPITECH PROJECT, 2023
** my_putstr.c
** File description:
** my_putstr
*/

#include "my.h"

void my_putchar(char c)
{
    write(1, &c, 1);
}

int my_putstr(char const *str)
{
    int a;

    for (a = 0; str[a] != '\0'; a++) {
        my_putchar(str[a]);
    }
    return 0;
}
