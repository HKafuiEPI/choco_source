/*
** EPITECH PROJECT, 2024
** error_cases.c
** File description:
** for error cases
*/

#include "my.h"

int check_other_symbols(char *str)
{
    char current;

    for (int j = 0; str[j] != '\0'; j++) {
        current = str[j];
        if ((current < '0' || current > '9') && current != '.' &&
        current != 'o' && current != '\n') {
            return 84;
        }
    }
    return 0;
}

int check_number(char *str)
{
    char current;

    for (int j = 0; str[j] != '\0'; j++) {
        current = str[j];
        if (current < '0' || current > '9') {
            return 84;
        }
    }
    return 0;
}

int check_arguments(char *str)
{
    char current;

    for (int j = 0; str[j] != '\0'; j++) {
        current = str[j];
        if (current != '.' && current != 'o') {
            return 84;
        }
    }
    return 0;
}

int error_cases(int argc, char **argv)
{
    char *str;

    if (argc != 2 && argc != 3)
        return 84;
    if (argc == 2) {
        str = fs_open_file(argv[1]);
        if (str == NULL || my_strlen(str) == 0)
            return 84;
        if (check_other_symbols(str) == 84)
            return 84;
    }
    if (argc == 3) {
        if (check_number(argv[1]) == 84)
            return 84;
        if (check_arguments(argv[2]) == 84)
            return 84;
    }
    return 0;
}
