/*
** EPITECH PROJECT, 2024
** okjn
** File description:
** rfc
*/

#include <unistd.h>
#include <string.h>
#include <stdio.h>
int main(void)
{
    int a = 1;
    int b = 1;
    int c =  a + b;

    printf("%d\n", c);
}
