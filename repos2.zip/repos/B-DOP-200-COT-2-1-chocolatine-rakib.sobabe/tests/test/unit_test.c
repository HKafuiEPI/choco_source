/*
** EPITECH PROJECT, 2023
** epitech
** File description:
** desc
*/
#include <criterion/criterion.h>
#include <criterion/redirect.h>
#include "../../my.h"
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

Test(count, bad_string1)
{
    count("2*3");
}
