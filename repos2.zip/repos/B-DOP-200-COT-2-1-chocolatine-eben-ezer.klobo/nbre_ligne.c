/*
** EPITECH PROJECT, 2023
** nombre de ligne
** File description:
** nombre de ligne
*/

#include <stdio.h>
#include <stdlib.h>
#include "my.h"

int nbr_ligne(char const *tempo)
{
    int i = 0;
    int count = 0;

    for (i = 0; tempo[i] != '\0'; i++) {
        if (tempo[i] == '\n') {
            count ++;
        }
    }
    return (count);
}
