/*
** EPITECH PROJECT, 2023
** my_cat
** File description:
** my_cat
*/

#include "my.h"

void ncurse_fonction(char **array, char **array2)
{
    int i = 0;
    int b;

    initscr();
    noecho();
    keypad(stdscr, true);
    while (1) {
        move((LINES / LINES) / 2, (COLS / COLS) / 2);
        for (i = 0; array[i] != NULL; i++) {
            printw(array[i]);
            printw("\n");
        }
        b = getch();
        array = all_movment(array, array2, b);
        if (b == ' ')
            break;
    }
    endwin();
}

char **string_array2(char *chemin, char **tab, int i)
{
    int a = count_char(chemin);
    int b = nbr_ligne(chemin);

    tab = malloc(sizeof(char *) * (b + 1));
    for ( ; i < b; i++)
        tab[i] = malloc(sizeof(char *) *(a + 1));
        return tab;
}

char **string_array(char *chemin)
{
    int i = 0;
    int j = 0;
    int c = 0;
    char **tab;

    tab = string_array2(chemin, tab, i);
    for (i = 0; chemin[i] != '\0'; i++) {
        if (chemin[i] == '\n') {
            tab[j][c] = '\0';
            j++;
            c = 0;
        } else {
            tab[j][c] = chemin[i];
            c++;
        }
    }
    return tab;
}

int usage(int ac, char **av)
{
    if (ac == 2 && av[1][0] == '-' && av[1][1] == 'h') {
        mini_printf("USAGE\n");
        mini_printf("\t./my_sokoban map\n");
        mini_printf("DESCRIPTION\n");
        mini_printf("\tmap file representing ");
        mini_printf("the warehouse map, containing '#' for walls,\n");
        mini_printf("\t    'P' for the player, 'X' ");
        mini_printf("for boxes and 'O' for storage locations.\n");
        return 0;
    }
}

int main(int argc, char **argv)
{
    char **array = NULL;
    char **array2 = NULL;
    int char_count = 0;
    int line_count = 0;
    char *file_contents = NULL;
    int *test;

    usage(argc, argv);
    file_contents = read_fil(argv[1]);
    array = string_array(file_contents);
    array2 = string_array(file_contents);
    test = player_position(array);
    char_count = count_char(file_contents);
    line_count = nbr_ligne(file_contents);
    if (argc != 2) {
        return 84;
    }
    ncurse_fonction(array, array2);
    return 0;
}
