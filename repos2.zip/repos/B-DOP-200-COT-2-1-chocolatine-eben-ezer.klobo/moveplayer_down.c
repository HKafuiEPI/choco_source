/*
** EPITECH PROJECT, 2023
** my_cat
** File description:
** my_cat
*/
#include "my.h"

void move_player_down2(char **array, int i, int j)
{
    if (array[i][j] == 'P' && array[i + 1][j] == ' ') {
        array[i][j] = ' ';
        array[i + 1][j] = 'P';
    }
    if (array[i][j] == 'P' && array[i + 1][j] == 'O') {
        array[i][j] = ' ';
        array[i + 1][j] = 'P';
    }
    if (array[i][j] == 'P' && array[i + 1][j] == 'X') {
        array[i][j] = ' ';
        array[i + 1][j] = 'P';
        array[i + 2][j] = 'X';
    }
}

char **moveplayer_down(char **array, char **array2)
{
    int *test;
    int i = 0;
    int j = 0;

    test = player_position(array);
    i = test[0];
    j = test[1];
    if (array[i][j] == 'P' && array[i + 1][j] == 'X'
        && array[i + 2][j] == '#') {
        return array;
    }
    if (array[i][j] == 'P' && array[i + 1][j] == 'X'
        && array[i + 2][j] == 'X') {
        return array;
    }
    move_player_down2(array, i, j);
    if (array2[i][j] == 'O' && array[i][j] != array2[i][j]) {
        array[i][j] = array2[i][j];
    }
    return array;
}
