/*
** EPITECH PROJECT, 2023
** mini_printf
** File description:
** mini_printf
*/

#include "my.h"

void pourcentage(const char *format, va_list args, int i)
{
    switch (format[i]) {
    case 'd':
    case 'i':
        my_put_nbr(va_arg(args, int));
        break;
    case 's':
        my_putstr(va_arg(args, char *));
        break;
    case 'c':
        my_putchar(va_arg(args, int));
        break;
    case '%':
        my_putchar('%');
        break;
    default:
        my_putchar('%');
        my_putchar(format[i]);
        break;
    }
}

int mini_printf(const char *format, ...)
{
    char carac;
    int i = 0;
    va_list args;

    va_start(args, format);
    while (format[i] != '\0') {
        switch (format[i]) {
        case '%':
            i++;
            pourcentage(format, args, i);
            break;
        default:
            my_putchar(format[i]);
            break;
        }
        i++;
    }
    va_end(args);
    return 0;
}
