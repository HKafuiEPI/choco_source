/*
** EPITECH PROJECT, 2023
** my_cat
** File description:
** my_cat
*/

#include "my.h"

void moveplayer_up2(char **array, char **array2, int i, int j)
{
    if (array[i][j] == 'P' && array[i - 1][j] == ' ') {
        array[i][j] = ' ';
        array[i - 1][j] = 'P';
    }
    if (array[i][j] == 'P' && array[i - 1][j] == 'O') {
        array[i][j] = ' ';
        array[i - 1][j] = 'P';
    }
    if (array[i][j] == 'P' && array[i - 1][j] == 'X') {
        array[i][j] = ' ';
        array[i - 1][j] = 'P';
        array[i - 2][j] = 'X';
    }
}

void moveplayer_up3(char **array, char **array2, int i, int j)
{
    if (array[i][j] == 'P' && array[i - 1][j] == 'X'
        && array[i - 2][j] == 'O') {
        array[i][j] = ' ';
        array[i - 1][j] = 'X';
    }
    if (array2[i][j] == 'O' && array[i][j] != array2[i][j])
        array[i][j] = array2[i][j];
}

char **moveplayer_up(char **array, char **array2)
{
    int i = 0;
    int j = 0;
    int *test = player_position(array);

    i = test[0];
    j = test[1];
    if (array[i][j] == 'P' && array[i - 1][j] == 'X'
        && array[i - 2][j] == '#') {
        return array;
    }
    if (array[i][j] == 'P' && array[i - 1][j] == 'X'
        && array[i - 2][j] == 'X') {
        return array;
    }
    moveplayer_up2(array, array2, i, j);
    moveplayer_up3(array, array2, i, j);
    return array;
}
