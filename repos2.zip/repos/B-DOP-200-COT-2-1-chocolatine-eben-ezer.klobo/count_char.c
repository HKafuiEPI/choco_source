/*
** EPITECH PROJECT, 2023
** my_cat
** File description:
** my_cat
*/

#include "my.h"

int count_char(char *count)
{
    int a = 0;
    int j = 0;
    int first_line = 0;
    int i = 0;

    for (j = 0; count[j] != '\0'; j++) {
        a++;
    }
    return a;
}
