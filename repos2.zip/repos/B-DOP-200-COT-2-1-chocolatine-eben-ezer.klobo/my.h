/*
** EPITECH PROJECT, 2023
** epitech
** File description:
** epitech
*/

#ifndef MY_H
    #define MY_H

    #include <stdlib.h>
    #include <stdio.h>
    #include <stdarg.h>
    #include <string.h>
    #include <unistd.h>
    #include <fcntl.h>
    #include <sys/stat.h>
    #include <ncurses.h>

void my_putchar(char c);

float my_putfloat(float nb, int sp);

int my_strcmp(char const *s1, char const *s2);

int my_put_nbr(int nb);

char *my_strncpy(char *dest, char const *src, int n);

int my_strncmp(char const *s1, char const *s2, int n);

long long int my_power(int nb, int p);

char *my_strupcase(char *str);

int my_putstr(char const *str);

int my_strlen(char const *str);

int my_getnbr(char const *str);

int real_digit(int a);

int is_digit(char c);

int display_char(int a, va_list list, char const *format);

int display_wrong_setting(int a, va_list list, const char *format);

int display_string(int a, va_list list, char const *format);

int display_int(int a, va_list list, char const *format);

int display_long_uns(int a, va_list list, const char *format);

int display_space_int(int a, va_list list, char const *format);

int display_short(int a, va_list list, const char *format);

int display_percent(int a, va_list list, char const *format);

int display_float(int a, va_list list, char const *format);

int display_hexadecimal(int a, va_list list, char const *format);

unsigned int display_unsigned(int a, va_list list, char const *format);

int display_diez_hexadecimalx(int a, va_list list, const char *format);

float display_point_float(int a, va_list list, const char *format);

int display_diez_float(int a, va_list list, const char *format);

int display_dias_int(int a, va_list list, const char *format);

int display_long_hexadecimal(int a, va_list list, const char *format);

int display_pointeur(int a, va_list list, const char *format);

int display_binary(int a, va_list list, const char *format);

int display_octal(int a, va_list list, char const *format);

int display_errorcode(int a, char const *format);

int display_expo_upper(int a, va_list list, const char *format);

int display_expo(int a, va_list list, const char *format);

int my_convert_octal(unsigned int nb);

int display_espace_decimal(int a, va_list list, const char *format);

int display_sign(int a, va_list list, const char *format);

int my_octal_flags(int a, va_list list, char const *format);

int my_convert_x_hexadecimal(unsigned int hex);

int my_convert_xhexadecimal(unsigned int hex);

int my_convert_xhexadecimal(unsigned int hex);

int my_convert_binary(unsigned int hex);

int my_convert_hexadecimal_ptr(long long int hex);

int my_convert_to_expo(double nb);

int my_convert_to_expo2(double nb);

float my_point_float(float nbr);

unsigned int my_put_uns_nbr(unsigned int unsnbr);

int mini_printf(const char *format, ...);

int nbr_ligne(char const *tempo);

char **string_array(char *chemin);

int count_char(char *count);

char *read_fil(char *path);

int *find_square(char **daray, int nbline, int nbcols);

int cut(int y, int j, int *tab1, char **array);

int inter(int j, int *tab1, char **array);

void squar2(char **daray, int *tab1, int *resu);

int erreur(int ac, char **av);

int dife(char **av);

int dif(char *daray);

char **all_movment(char **array, char **array2, int presse);

int *player_position(char **tab);

char **moveplayer_up(char **array, char **array2);

char **moveplayer_down(char **array, char **array2);

char **moveplayer_left(char **array, char **array2);

char **moveplayer_right(char **array, char **array2);

#endif
