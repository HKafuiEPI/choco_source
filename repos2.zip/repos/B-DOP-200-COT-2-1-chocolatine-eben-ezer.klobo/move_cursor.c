/*
** EPITECH PROJECT, 2023
** my_cat
** File description:
** my_cat
*/

#include "my.h"

int *player_position(char **tab)
{
    int i = 0;
    int j = 0;
    int *pos = malloc(sizeof(int) * 2);

    while (tab[i] != NULL) {
        while (tab[i][j] != '\0') {
            if (tab[i][j] == 'P') {
                pos[0] = i;
                pos[1] = j;
            }
            j++;
        }
        i++;
        j = 0;
    }
    return pos;
}

char **all_movment(char **array, char **array2, int presse)
{
    if (presse == KEY_UP) {
        array = moveplayer_up(array, array2);
    }
    if (presse == KEY_DOWN) {
        array = moveplayer_down(array, array2);
    }
    if (presse == KEY_LEFT) {
        array = moveplayer_left(array, array2);
    }
    if (presse == KEY_RIGHT) {
        array = moveplayer_right(array, array2);
    }
    return array;
}
