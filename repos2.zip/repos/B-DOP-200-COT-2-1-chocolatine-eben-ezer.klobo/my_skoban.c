/*
** EPITECH PROJECT, 2023
** my_sokoban
** File description:
** my_sokoban
*/

#include "my.h"

char *read_fil(char *path)
{
    int fd;
    ssize_t bites;
    char *buffer;
    struct stat statbuf;
    int size;

    stat(path, &statbuf);
    size = statbuf.st_size;
    buffer = malloc(sizeof(char) * (size + 1));
    fd = open(path, O_RDONLY);
    (bites = read(fd, buffer, size)) > 0;
    if (fd == -1 || bites == 0 || bites == -1)
        exit(84);
    buffer[bites] = '\0';
    close(fd);
    return buffer;
}
