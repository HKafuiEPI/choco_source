/*
** EPITECH PROJECT, 2023
** my_cat
** File description:
** my_cat
*/

#include "my.h"

void moveplayer_left2(char **array, int i, int j)
{
    if (array[i][j] == 'P' && array[i][j - 1] == ' ') {
        array[i][j] = ' ';
        array[i][j - 1] = 'P';
    }
    if (array[i][j] == 'P' && array[i][j - 1] == 'O') {
        array[i][j] = ' ';
        array[i][j - 1] = 'P';
    }
    if (array[i][j] == 'P' && array[i][j - 1] == 'X') {
        array[i][j] = ' ';
        array[i][j - 1] = 'P';
        array[i][j - 2] = 'X';
    }
}

char **moveplayer_left(char **array, char **array2)
{
    int i = 0;
    int j = 0;
    int *test = player_position(array);

    i = test[0];
    j = test[1];
    if (array[i][j] == 'P' && array[i][j - 1] == 'X'
        && array[i][j - 2] == '#') {
        return array;
    }
    if (array[i][j] == 'P' && array[i][j - 1] == 'X'
        && array[i][j - 2] == 'X') {
        return array;
    }
    moveplayer_left2(array, i, j);
    if (array2[i][j] == 'O' && array[i][j] != array2[i][j]) {
        array[i][j] = array2[i][j];
    }
    return array;
}
