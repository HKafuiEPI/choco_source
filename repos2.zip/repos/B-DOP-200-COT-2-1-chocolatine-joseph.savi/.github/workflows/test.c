/*
** EPITECH PROJECT, 2024
** test
** File description:
** my file
*/

#include "stdio.h"
int main(int ac, char **av)
{
    int i = 2;
    int j = 3;
    int result = i + j;

    printf("Le résultat est: %d\n", result);
    return 0;
}
