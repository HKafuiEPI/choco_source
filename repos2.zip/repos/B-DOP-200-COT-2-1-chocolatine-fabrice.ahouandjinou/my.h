/*
** EPITECH PROJECT, 2023
** my_header
** File description:
** my_header_file
*/

#ifndef MY_INCLUDED
    #define MY_INCLUDED
    #include <unistd.h>
    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include <math.h>
void usage(void);
double **mat1(void);
double **mat2(void);
double **multiply_matrices(double **mat1, double **mat2, int r, int c);
#endif
