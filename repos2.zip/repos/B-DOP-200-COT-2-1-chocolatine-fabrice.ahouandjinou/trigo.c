/*
** EPITECH PROJECT, 2024
** trigo.c
** File description:
** khjv
*/

#include "my.h"
#include <string.h>

static int no_alphanum(char c)
{
    if (c >= '!' && c <= '/' || c >= ':' &&
	c <= '@' || c >= '[' && c <= '`' ||
        c >= '{' && c <= '~') {
        return 1;
    } else
        return 0;
}

int verify_char(char c)
{
    if (c <= 'z' && c >= 'a' || c <= 'Z' &&
        c >= 'A')
        return 1;
    else
        return 0;
}

int not_number(char **av)
{
    int w = 0;

    for (int j = 2; av[j] != NULL; j++) {
        for (int a = 0; av[j][a] != '\0'; a++) {
            if (verify_char(av[j][a]) == 1 || no_alphanum(av[j][a]) == 1)
                w = 1;
        }
    }
    if (w == 1)
        return 84;
    else
        return 0;
}

void usage(void)
{
    printf("USAGE\n");
    printf("    ./108trigo fun a0 a1 a2 ...\n");
    printf("\n");
    printf("DESCRIPTION\n");
    printf("     fun    function to be applied, among at least “EXP”, “COS”, “SIN”, “COSH”\n");
    printf("            and “SINH”\n");
    printf("     ai     coeficients of the matrix\n");
}

double **mat1(void)
{
    int z;
    double **mat1;
    mat1 = malloc(sizeof(double *) * 3);

    for(z = 0; z < 3; z++) {
        mat1[z] = malloc(sizeof(double) * 3);
    }
    mat1[0][0] = 3;
    mat1[0][1] = 2;
    mat1[0][2] = 1;
    mat1[1][0] = 1;
    mat1[1][1] = 2;
    mat1[1][2] = 3;
    mat1[2][0] = 6;
    mat1[2][1] = 2;
    mat1[2][2] = 3;
    return mat1;
}

double **mat2(void)
{
    int z;
    double **mat2;
    mat2 = malloc(sizeof(double *) * 3);

    for(z = 0; z < 3; z++) {
        mat2[z] = malloc(sizeof(double) * 3);
    }
    mat2[0][0] = 6;
    mat2[0][1] = 5;
    mat2[0][2] = 2;
    mat2[1][0] = 3;
    mat2[1][1] = 2;
    mat2[1][2] = 1;
    mat2[2][0] = 6;
    mat2[2][1] = 4;
    mat2[2][2] = 7;
    return mat2;
}

double **multiply_matrices(double **mat1, double **mat2, int r, int c)
{
    double **mul = malloc(sizeof(double *) * (r + 1));
    int i = 0;
    int j = 0;
    int k = 0;
    int n = 0;
    int m = 0;

    for (i = 0; i < c; i++) {
        for (j = 0; j < c; j++) {
            mul[i][j] = 0;
            for (k = 0; k < c; k++) {
                mul[i][j] += mat1[i][k] * mat2[k][j];
            }
        }
    }

    for(i = 0; i < n; i++) {
        for(j = 0; j < m; j++) {
            printf("%d\t",mul[i][j]);
        }
        printf("\n");
    }
    return 0;
}


int mes_fonc(char *av)
{
    if (strcmp("COS", av) == 0 ||
        strcmp("COSH", av) == 0 || strcmp("SIN", av) == 0 ||
        strcmp("SINH", av) == 0 || strcmp("EXP", av) == 0)
        return 0;
    else
        return 84;
}

int count(char **av)
{
    int j = 0;

    for (int t = 2; av[t] != NULL; t++)
        j++;
    return j;
}

int main(int ac, char **av)
{
    return 84;
}
