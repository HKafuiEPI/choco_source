/*
** EPITECH PROJECT, 2023
** gg
** File description:
** gg
*/

#include "include/my.h"

int my_strlen(char *str)
{
    int b = 0;

    for (b = 0; str[b] != '\0'; b++) {
    }
    return b;
}
