/*
** EPITECH PROJECT, 2024
** CHOCOLATINE
** File description:
** my.h
*/

#include <stdio.h>

void printmsg(void);

#pragma once
