/*
** EPITECH PROJECT, 2024
** CHOCOLATINE
** File description:
** main.c
*/

#include "include/my.h"

int main(void)
{
    printmsg();
    return 0;
}
