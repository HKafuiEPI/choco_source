/*
** EPITECH PROJECT, 2024
** CHOCOLATINE
** File description:
** func.c
*/

#include "include/my.h"

void printmsg(void)
{
    printf("Admin:\n\tHello world!\n");
}
