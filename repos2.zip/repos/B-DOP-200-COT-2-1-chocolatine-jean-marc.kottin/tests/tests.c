/*
** EPITECH PROJECT, 2024
** B-MAT-200-COT-2-1-107transfer-jordan.amouzoun
** File description:
** tests
*/

#include <criterion/criterion.h>
#include <criterion/redirect.h>
#include "../include/my.h"

void redirect_all_std(void)
{
    cr_redirect_stdout();
    cr_redirect_stderr();
}

Test(printmsg, printf_a_message, .init = redirect_all_std)
{
    printmsg();
}