/*
** EPITECH PROJECT, 2023
** my.h
** File description:
** diplay prototypes
*/

#ifndef MY_H
    #define MY_H
    #include <string.h>
    #include <stdlib.h>
    #include <stdio.h>
    #include <unistd.h>

#endif
