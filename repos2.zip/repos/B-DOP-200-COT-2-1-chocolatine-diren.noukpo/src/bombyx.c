/*
** EPITECH PROJECT, 2024
** epitech
** File description:
** 106bombyx.c
*/

#include <stdio.h>
#include <stdlib.h>

void display_h(void)
{
    printf("USAGE\n    ./106bombyx n [k | i0 i1]\n\nDESCRIPTION\n    n      ");
    printf(" number of first generation individuals\n    k      ");
    printf(" growth rate from 1 to 4\n    i0      initial generation (includ");
    printf("ed)\n    i1      final generation (included)\n");
}

int cheker_size(char *size, int argc, char **argv)
{
    int i = 0;

    if (*size == '\0')
        return 84;
    if (atoi(argv[1]) != atof(argv[1]) || atoi(argv[1]) < 0)
        return 84;
    if (argc == 4) {
        if (atoi(argv[2]) != atof(argv[2]) || atoi(argv[2]) != atof(argv[2])
        || atoi(argv[2]) <= 0 || atoi(argv[3]) <= 0 ||
        atoi(argv[3]) < atoi(argv[2]))
            return 84;
    }
    if (argc == 3 && atof(argv[2]) > 4 || argc == 3 && atof(argv[2]) <= 0)
        return 84;
    while (size[i] != '\0') {
        if ((size[i] >= '0' && size[i] <= '9') || size[i] == '.') {
            i++;
        } else
            return (84);
    }
}

double gen_formula1(char **argv, int argc)
{
    double x;
    double k;
    int b;

    if (cheker_size(argv[1], argc, argv) == 84 ||
    cheker_size(argv[2], argc, argv) == 84)
        return 84;
    x = atof(argv[1]);
    k = atof(argv[2]);
    b = x;
    for (int a = 1; a <= 100; a++) {
        printf("%d %.2f\n", a, x >= 0 ? x : 0);
        x = k * x * (1000.0 - x) / 1000.0;
    }
    return 0;
}

double gen_formula2(char **argv, int argc)
{
    int i1 = atoi(argv[2]);
    int i2 = atoi(argv[3]);
    double x;

    if (cheker_size(argv[1], argc, argv) == 84 ||
    cheker_size(argv[2], argc, argv) == 84 ||
    cheker_size(argv[3], argc, argv) == 84)
        return 84;
    for (double a = 1; a <= 4; a = a + 0.01) {
        x = atof(argv[1]);
        for (int i = 1; i < i1; i++)
            x = a * x * (1000 - x) / 1000;
        printf("%.2f %.2f\n", a, x);
        for (int j = i1; j < i2; j++) {
            x = a * x * (1000.0 - x) / 1000;
            printf("%.2f %.2f\n", a, x >= 0 ? x : 0);
        }
    }
    return 0;
}
