/*
** EPITECH PROJECT, 2024
** epitech
** File description:
** desc
*/

#ifndef MY_106BOMBYX_H_
    #define MY_106BOMBYX_H_

void display_h(void);

double gen_formula1(char **argv, int argc);

double gen_formula2(char **argv, int argc);

int cheker_size(char *size, int argc, char **argv);

#endif
