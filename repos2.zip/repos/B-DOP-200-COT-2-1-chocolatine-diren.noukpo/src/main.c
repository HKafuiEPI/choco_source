/*
** EPITECH PROJECT, 2024
** epitech
** File description:
** desc
*/

#include "bombyx.h"
#include <string.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
    if (argc == 1 || argc > 4)
        return 84;
    if (argc == 2 && strcmp(argv[1], "-h") != 0)
        return 84;
    if (argc == 2 && strcmp(argv[1], "-h") == 0)
        display_h();
    if (argc == 3)
        return gen_formula1(argv, argc);
    if (argc == 4) {
        return gen_formula2(argv, argc);
    }
    return 0;
}
