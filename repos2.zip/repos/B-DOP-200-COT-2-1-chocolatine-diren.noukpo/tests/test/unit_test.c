/*
** EPITECH PROJECT, 2023
** epitech
** File description:
** desc
*/
#include <criterion/criterion.h>
#include <criterion/redirect.h>
#include "../../src/bombyx.h"
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

Test(display_h, is_define)
{
    display_h();
}


Test(cheker_size, bad_string)
{
    char **argv = malloc(sizeof(char *) * 4);
    argv[0] = strdup("");
    argv[1] = strdup("a10");
    argv[2] = strdup("10000");
    argv[3] = strdup("10010");
    argv[4] = NULL;
    int argc = 4;
    int res = cheker_size(argv[1], argc, argv);

    cr_assert_eq(res, 84);
}

Test(cheker_size, bad_string1)
{
    char **argv = malloc(sizeof(char *) * 4);
    argv[0] = strdup("");
    argv[1] = strdup("10");
    argv[2] = strdup("a10000");
    argv[3] = strdup("10010");
    argv[4] = NULL;
    int argc = 4;
    int res = cheker_size(argv[1], argc, argv);

    cr_assert_eq(res, 84);
}

Test(cheker_size, bad_string2)
{
    char **argv = malloc(sizeof(char *) * 4);
    argv[0] = strdup("");
    argv[1] = strdup("10");
    argv[2] = strdup("10000");
    argv[3] = strdup("a10010");
    argv[4] = NULL;
    int argc = 4;
    int res = cheker_size(argv[1], argc, argv);

    cr_assert_eq(res, 84);
}
Test(cheker_size, bad_string3)
{
    char **argv = malloc(sizeof(char *) * 4);
    argv[0] = strdup("");
    argv[1] = strdup("10");
    argv[2] = strdup("10000");
    argv[3] = strdup("10010");
    argv[4] = NULL;
    int argc = 4;
    int res = cheker_size(argv[1], argc, argv);

    cr_assert_eq(res, 0);
}

Test(cheker_size, bad_string4)
{
    char **argv = malloc(sizeof(char *) * 4);
    argv[0] = strdup("");
    argv[1] = strdup("-10");
    argv[2] = strdup("10000");
    argv[3] = strdup("10010");
    argv[4] = NULL;
    int argc = 4;
    int res = cheker_size(argv[1], argc, argv);

    cr_assert_eq(res, 84);
}

Test(cheker_size, bad_string5)
{
    char **argv = malloc(sizeof(char *) * 4);
    argv[0] = strdup("");
    argv[1] = strdup("10.5");
    argv[2] = strdup("a10000");
    argv[3] = strdup("10010");
    argv[4] = NULL;
    int argc = 4;
    int res = cheker_size(argv[1], argc, argv);

    cr_assert_eq(res, 84);
}

Test(cheker_size, bad_string6)
{
    char **argv = malloc(sizeof(char *) * 4);
    argv[0] = strdup("");
    argv[1] = strdup("10");
    argv[2] = strdup("10000.5");
    argv[3] = strdup("10010");
    argv[4] = NULL;
    int argc = 4;
    int res = cheker_size(argv[1], argc, argv);

    cr_assert_eq(res, 84);
}

Test(cheker_size, bad_string7)
{
    char **argv = malloc(sizeof(char *) * 4);
    argv[0] = strdup("");
    argv[1] = strdup("10");
    argv[2] = strdup("3.3");
    argv[3] = NULL;
    int argc = 3;
    int res = cheker_size(argv[1], argc, argv);

    cr_assert_eq(res, 0);
}

Test(cheker_size, bad_string8)
{
    char **argv = malloc(sizeof(char *) * 4);
    argv[0] = strdup("");
    argv[1] = strdup("10");
    argv[2] = strdup("-3.3");
    argv[3] = NULL;
    int argc = 3;
    int res = cheker_size(argv[1], argc, argv);

    cr_assert_eq(res, 84);
}


Test(cheker_size, bad_string9)
{
    char **argv = malloc(sizeof(char *) * 4);
    argv[0] = strdup("");
    argv[1] = strdup("10");
    argv[2] = strdup("5");
    argv[3] = NULL;
    int argc = 3;
    int res = cheker_size(argv[1], argc, argv);

    cr_assert_eq(res, 84);
}

Test(cheker_size, bad_string10)
{
    char **argv = malloc(sizeof(char *) * 4);
    argv[0] = strdup("");
    argv[1] = strdup("10.0");
    argv[2] = strdup("3.3");
    argv[3] = NULL;
    int argc = 3;
    int res = cheker_size(argv[1], argc, argv);

    cr_assert_eq(res, 0);
}

Test(cheker_size, bad_string11)
{
    char **argv = malloc(sizeof(char *) * 4);
    argv[0] = strdup("");
    argv[1] = strdup("\0");
    argv[2] = strdup("3.3");
    argv[3] = NULL;
    int argc = 3;
    int res = cheker_size(argv[1], argc, argv);

    cr_assert_eq(res, 84);
}
Test(cheker_size, bad_string12)
{
    char **argv = malloc(sizeof(char *) * 4);
    argv[0] = strdup("");
    argv[1] = strdup("10");
    argv[2] = strdup("10000");
    argv[3] = strdup("10");
    argv[4] = NULL;
    int argc = 4;
    int res = cheker_size(argv[1], argc, argv);

    cr_assert_eq(res, 84);
}

Test(gen_formula1, is_define)
{
    int argc = 3;
    char **argv = malloc(sizeof(char *) * 4);
    argv[0] = strdup("");
    argv[1] = strdup("10");
    argv[2] = strdup("3.3");
    argv[3] = NULL;
    gen_formula1(argv, argc);
}

Test(gen_formula1, is_define1)
{
    int argc = 3;
    char **argv = malloc(sizeof(char *) * 4);
    argv[0] = strdup("");
    argv[1] = strdup("a10");
    argv[2] = strdup("3.3");
    argv[3] = NULL;
    gen_formula1(argv, argc);
}

Test(gen_formula1, is_define2)
{
    int argc = 3;
    char **argv = malloc(sizeof(char *) * 4);
    argv[0] = strdup("");
    argv[1] = strdup("10");
    argv[2] = strdup("3.3");
    argv[3] = NULL;
    gen_formula1(argv, argc);
}

Test(gen_formula1, is_define3)
{
    int argc = 3;
    char **argv = malloc(sizeof(char *) * 4);
    argv[0] = strdup("");
    argv[1] = strdup("10");
    argv[2] = strdup("3.3");
    argv[3] = NULL;
    gen_formula1(argv, argc);
}

Test(gen_formula2, is_define)
{
    int argc = 4;
    char **argv = malloc(sizeof(char *) * 5);
    argv[0] = strdup("");
    argv[1] = strdup("10");
    argv[2] = strdup("10000");
    argv[3] = strdup("10100");
    argv[4] = NULL;
    gen_formula2(argv, argc);
}

Test(gen_formula2, is_define2)
{
    int argc = 4;
    char **argv = malloc(sizeof(char *) * 5);
    argv[0] = strdup("");
    argv[1] = strdup("a10");
    argv[2] = strdup("10000");
    argv[3] = strdup("10100");
    argv[4] = NULL;
    gen_formula2(argv, argc);
}

Test(gen_formula2, is_define3)
{
    int argc = 4;
    char **argv = malloc(sizeof(char *) * 5);
    argv[0] = strdup("");
    argv[1] = strdup("10");
    argv[2] = strdup("a10000");
    argv[3] = strdup("10100");
    argv[4] = NULL;
    gen_formula2(argv, argc);
}

Test(gen_formula2, is_define4)
{
    int argc = 4;
    char **argv = malloc(sizeof(char *) * 5);
    argv[0] = strdup("");
    argv[1] = strdup("10");
    argv[2] = strdup("10000");
    argv[3] = strdup("a10100");
    argv[4] = NULL;
    gen_formula2(argv, argc);
}
