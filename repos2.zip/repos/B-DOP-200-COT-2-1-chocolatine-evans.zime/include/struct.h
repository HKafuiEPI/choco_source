/*
** EPITECH PROJECT, 2024
** amazed
** File description:
** amazed by FaroukjGRNT, Noge and Evanszime
*/

#ifndef STRUCT_H
    #define STRUCT_H
    #define SIZE_BUF  1000000
    #define TRUE 1
    #define FALSE 0

typedef struct st {
    char *buffer;
    char **tab;
    char *rstart;
    char **start;
    char *rend;
    char **end;
}global_t;

typedef struct tunnel {
    struct tunnel_t **access_tunnel;
    int len;
    int id;
    int x;
    int y;
    int start;
    int end;
} tunnel_t;

typedef struct amaze {
    char *file_content;
    tunnel_t **tunnel;
    int entity_len;
    int tunnel_len;
    int total_entities;
    int callback;
} amaze_t;

#endif
