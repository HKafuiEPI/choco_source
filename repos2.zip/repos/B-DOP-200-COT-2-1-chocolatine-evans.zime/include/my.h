/*
** EPITECH PROJECT, 2024
** amazed
** File description:
** amazed by FaroukjGRNT, Noge and Evanszime
*/

#ifndef MY_H
    #define MY_H
    #include <stdio.h>
    #include <stdlib.h>
    #include <unistd.h>
    #include <stdarg.h>
    #include <fcntl.h>
    #include <dirent.h>
    #include <sys/stat.h>
    #include <stdarg.h>
    #include <string.h>
    #include <math.h>
    #include <signal.h>
    #include <ctype.h>
    #include "struct.h"

int get_maze(global_t *set);
int check_arg(int ac, char **av, global_t *set);
char **build_tab(char *buf);
void my_putchar(char c);
int is_num(char *str);
int check_instr2(global_t *set);
char **in_tab(global_t *set, int i);
void display_nb(global_t *set);
int my_putstr(char const *src);
int my_putstrer(char const *src);
long my_putnbr(long i);
void skip_comms(global_t *set);
int check_instr(global_t *set);
int buffer_to_tab(global_t *set);
int multi_cmp(char *str);
static int del_com_bis(global_t *set, int i, int j);
int is_tunnels(char *str);

int main(int ac, char **av);

int my_strlen(char const *src);
int my_strcmp(char const *s1, char const *s2);
int my_getnbr(char const *str);
char *my_strcat(char *path, char *command);
char *my_strcpy(char *dest, char const *src);
char **my_str_to_word_array(char const *str);

#endif
