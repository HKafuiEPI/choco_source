/*
** EPITECH PROJECT, 2024
** test.c
** File description:
** test.c
*/

#include "../include/my.h"
#include <criterion/criterion.h>
#include <criterion/redirect.h>

Test(my_putchar, is_defined)
{
    my_putchar('c');
}

Test(my_putstr, is_string)
{
    my_putstr("ybyebeee");
}

Test(my_strlen, is_caracter)
{
    int i = my_strlen("farouk");
    cr_assert_eq(i, 6);
}

Test(my_strcpy, is_copy)
{
    char src[20] = "Hello, world!";
    char dest[20];
    my_strcpy(dest, src);
}

Test(my_strcmp, is_compared)
{
    char const s1[6] = "farouk";
    char const s2[6] = "madiya";
    my_strcmp(s1, s2);
}

Test(my_strcmp, is_compared4)
{
    char const s1[6] = "farouk";
    char const s2[6] = "farouk";
    int r = my_strcmp(s1, s2);
    cr_assert_eq(r, 0);
}

Test(is_num, one2)
{
    is_num("23739");
}
