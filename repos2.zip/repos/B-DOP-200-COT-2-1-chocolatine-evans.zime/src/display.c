/*
** EPITECH PROJECT, 2024
** amazed
** File description:
** amazed by FaroukjGRNT, Noge and Evanszime
*/

#include "../include/my.h"

void display_moves(global_t *set)
{
    my_putstr("#moves\n");
}

void display_tunnels(global_t *set)
{
    my_putstr("#tunnels\n");
    for (int i = 0; set->tab[i]; i++) {
        if (is_tunnels(set->tab[i]) == FALSE){
            my_putstr(set->tab[i]);
            my_putchar('\n');
        }
    }
}

void display_en(global_t *set)
{
    int st = 0;

    my_putstr("##end\n");
    for (int i = 0; set->tab[i]; i++)
        if (my_strcmp(set->tab[i], "##end"))
            st = i + 1;
    for (int i = st; set->tab[i]; i++){
        if (is_tunnels(set->tab[i]) == FALSE
        || my_strcmp(set->tab[i], "##start"))
            break;
        my_putstr(set->tab[i]);
        my_putchar('\n');
    }
}

void display_st(global_t *set)
{
    int st = 0;

    my_putstr("##start\n");
    for (int i = 0; set->tab[i]; i++)
        if (my_strcmp(set->tab[i], "##start"))
            st = i + 1;
    for (int i = st; set->tab[i]; i++){
        if (is_tunnels(set->tab[i]) == FALSE
        || my_strcmp(set->tab[i], "##end"))
            break;
        my_putstr(set->tab[i]);
        my_putchar('\n');
    }
}

void display_nb(global_t *set)
{
    my_putstr("#number_of_robots\n");
    my_putstr(set->tab[0]);
    my_putstr("\n#rooms\n");
    for (int i = 1; set->tab[i]; i++){
        if (my_strcmp(set->tab[i], "##start")
        || my_strcmp(set->tab[i], "##end"))
            break;
        else {
            my_putstr(set->tab[i]);
            my_putchar('\n');
        }
    }
    display_st(set);
    display_en(set);
    display_tunnels(set);
    display_moves(set);
}
