/*
** EPITECH PROJECT, 2023
** my_sokoban
** File description:
** main
*/

#include "../include/my.h"

int multi_cmp(char *str)
{
    if (my_strcmp(str, "##start"))
        return (TRUE);
    if (my_strcmp(str, "##end"))
        return (TRUE);
    return (FALSE);
}

static int del_com_bis(global_t *set, int i, int j)
{
    if (multi_cmp(set->tab[i]) == FALSE) {
        set->tab[i] = NULL;
        set->tab[j] = NULL;
        i--;
    }
    return (i);
}

char **in_tab(global_t *set, int i)
{
    for (int k = 0; set->tab[i][k] != '\0'; k++)
        if (set->tab[i][k] == '#' && k != 0 && k != 1)
            set->tab[i][k] = '\0';
    return set->tab;
}

void skip_comms(global_t *set)
{
    int j = 0;

    for (int i = 0; set->tab[i] != NULL; i++)
        if (set->tab[i][0] == '#' && set->tab[i][1] != '#')
            i = del_com_bis(set, i, j);
    for (int i = 0; set->tab[i] != NULL; i++) {
        if (set->tab[i][0] == '#' && set->tab[i][1] != '#')
            i++;
        set->tab = in_tab(set, i);
    }
}
