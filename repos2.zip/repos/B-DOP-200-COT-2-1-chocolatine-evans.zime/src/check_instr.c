/*
** EPITECH PROJECT, 2024
** amazed
** File description:
** amazed by FaroukjGRNT, Noge and Evanszime
*/

#include "../include/my.h"


int is_tunnels(char *str)
{
    for (int i = 0; str[i]; i++)
        if (str[i] == '-')
            return FALSE;
    return TRUE;
}

int check_instr2(global_t *set)
{
    int ro = 0;

    for (int i = 1; set->tab[i]; i++){
        if (my_strcmp(set->tab[i], "##start")
        || my_strcmp(set->tab[i], "##end"))
            break;
        else
            ro++;
    }
    if (ro == 0)
        return 84;
    return 0;
}

int check_instr(global_t *set)
{
    int st = 0;
    int en = 0;

    for (int i = 0; set->tab[i]; i++){
        if (my_strcmp(set->tab[i], "##start"))
            st++;
        if (my_strcmp(set->tab[i], "##end"))
            en++;
    }
    if (check_instr2(set) == 84)
        return 84;
    if (st != 1 || en != 1 || (st != 1 && en != 1))
        return 84;
    if (set->tab[0] == NULL || (is_num(set->tab[0]) == 84))
        return 84;
    return 0;
}
