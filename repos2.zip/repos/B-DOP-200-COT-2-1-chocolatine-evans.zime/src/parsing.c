/*
** EPITECH PROJECT, 2024
** amazed
** File description:
** amazed by FaroukjGRNT, Noge and Evanszime
*/

#include "../include/my.h"

int buffer_to_tab(global_t *set)
{
    if (set->buffer == NULL)
        return 84;
    set->tab = my_str_to_word_array(set->buffer);
    skip_comms(set);
    if (check_instr(set) == 84)
        return 84;
    display_nb(set);
    return 0;
}

int get_maze(global_t *set)
{
    int num = 0;
    int offset = 0;
    int len;

    set->buffer = malloc(SIZE_BUF * sizeof(char));
    len = read(STDIN_FILENO, set->buffer + offset, SIZE_BUF - offset);
    num += len;
    while ((len) > 0) {
        len = read(STDIN_FILENO, set->buffer + offset, SIZE_BUF - offset);
        offset += len;
        num += len;
    }
    set->buffer[num] = '\0';
    if (len < 0)
        return 84;
    if (buffer_to_tab(set) == 84)
        return 84;
}

int check_arg(int ac, char **av, global_t *set)
{
    int r = 0;

    if (ac == 2 && my_strcmp(av[1], "-h") == 0){
        my_putstr("USAGE: ./amazed < [FILE]\n");
    } else if (ac == 1)
        r = get_maze(set);
    else
        r = 84;
    return r;
}
