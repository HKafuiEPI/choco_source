/*
** EPITECH PROJECT, 2024
** amazed
** File description:
** amazed by FaroukjGRNT, Noge and Evanszime
*/

#include "../include/my.h"

int main(int ac, char **av)
{
    global_t set;
    int errnum;

    errnum = check_arg(ac, av, &set);
    return errnum;
}
