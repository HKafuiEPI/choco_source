/*
** EPITECH PROJECT, 2023
** organized
** File description:
** string_toolbox2
*/

#include "../../include/my.h"

int is_num(char *str)
{
    for (int i = 0; str[i] != 0; i++) {
        if (!(str[i] <= '9' && str[i] >= '0'))
        return 84;
    }
    return 0;
}

int tab_len(char **tab)
{
    int n = 0;

    while (tab[n] != 0)
        n++;
    return n;
}

void free_tab(char **tab)
{
    for (int i = 0; tab[i] != NULL; i++) {
        free(tab[i]);
    }
    free(tab);
}

int my_getnbr(char const *str)
{
    int n = 0;
    int r;
    int i;

    for (i = 0; str[i] == '-' || str[i] == '+'; i++) {
    }
    while (str[i] <= 57 && str[i] >= 48) {
        r = str[i] - 48;
        for (int j = i; str[j + 1] <= 57 && str[j + 1] >= 48; j++) {
            r = r * 10;
        }
        n = n + r;
        i++;
    }
    return (n);
}

void print_tab(char **tab)
{
    for (int i = 0; tab[i] != NULL; i++) {
        my_putstr(tab[i]);
        my_putchar('\n');
    }
}
