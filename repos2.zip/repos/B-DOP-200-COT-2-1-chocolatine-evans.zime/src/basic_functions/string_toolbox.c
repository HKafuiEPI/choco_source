/*
** EPITECH PROJECT, 2023
** my_putstr
** File description:
** A file containing functions to manipulate strings and chars
*/

#include "../../include/my.h"

void my_putchar(char c)
{
    write(1, &c, 1);
}

int my_putstr(char const *str)
{
    int n = 0;

    while (str[n] != '\0') {
        my_putchar(str[n]);
        n++;
    }
    return n;
}

int my_strlen(char const *str)
{
    int compt = 0;

    while (str[compt] != '\0') {
        compt ++;
    }
    return compt;
}

char *my_strcpy(char *dest, char const *src)
{
    int i = 0;

    while (src[i] != '\0') {
        dest[i] = src[i];
        i++;
    }
    dest[i] = '\0';
    return dest;
}

int my_strcmp(char const *s1, char const *s2)
{
    if (my_strlen(s1) != my_strlen(s2))
        return (0);
    for (int i = 0; s1[i] != '\0'; i++) {
        if (s1[i] != s2[i])
            return (0);
    }
    return (84);
}
