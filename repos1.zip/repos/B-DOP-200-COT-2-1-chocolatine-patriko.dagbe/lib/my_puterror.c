/*
** EPITECH PROJECT, 2023
** B-PSU-200-COT-2-1-minishell1-patriko.dagbe
** File description:
** my_puterror.c
*/

#include "../include/lib.h"

int my_puterror(int fd, const char *str, int exit_value)
{
    write(fd, str, my_strlen(str));
    return exit_value;
}
