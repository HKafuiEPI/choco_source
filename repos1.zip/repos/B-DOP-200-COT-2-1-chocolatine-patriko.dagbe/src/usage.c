/*
** EPITECH PROJECT, 2024
** B-MUL-200-COT-2-1-mypaint-patriko.dagbe
** File description:
** usage
*/
#include "../include/paint.h"
int usage(int ac, char **argv)
{
    if (ac == 2 && argv[1][0] == '-' && argv[1][1] == 'h') {
        my_putstr("DESCRIPTION\n");
        my_putstr(" To compili do this\n");
        my_putstr(" ./my_paint\n");
        return 0;
    }
}
