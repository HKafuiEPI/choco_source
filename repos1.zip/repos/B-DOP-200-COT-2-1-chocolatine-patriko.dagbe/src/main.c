/*
** EPITECH PROJECT, 2023
** B-MUL-200-COT-2-1-mypaint-patriko.dagbe
** File description:
** main.c
*/

#include "../include/paint.h"

menu_t *init_menu(sfVector2f position, sfVector2f size, sfColor color)
{
    menu_t *menu = malloc(sizeof(menu_t));
    menu->menu_rect = sfRectangleShape_create();
    sfRectangleShape_setPosition(menu->menu_rect, position);
    sfRectangleShape_setSize(menu->menu_rect, size);
    sfRectangleShape_setOutlineColor(menu->menu_rect, color);
    sfRectangleShape_setFillColor(menu->menu_rect, color);
    return menu;
}

button_t *init_button(sfVector2f position, sfVector2f size, sfColor color)
{
    button_t *button = malloc(sizeof(button_t));

    button->rect = sfRectangleShape_create();
    sfRectangleShape_setPosition(button->rect, position);
    sfRectangleShape_setSize(button->rect, size);
    sfRectangleShape_setOutlineThickness(button->rect, 1);
    sfRectangleShape_setOutlineColor(button->rect, sfBlack);
    sfRectangleShape_setFillColor(button->rect, color);
    button->is_clicked = &is_clicked;
    button->is_hover = &is_hover;
    return button;
}

static image_zone_t *init_image_zone(sfRenderWindow *window, sfColor color)
{
    image_zone_t *img_zone = malloc(sizeof(image_zone_t));
    sfVector2u w_size = sfRenderWindow_getSize(window);
    sfVector2u s_size;

    img_zone->color = color;
    img_zone->image = sfImage_createFromColor(1000, 600, img_zone->color);
    img_zone->image_texture = sfTexture_createFromImage(img_zone->image, NULL);
    img_zone->image_sprite = sfSprite_create();
    s_size = sfTexture_getSize(img_zone->image_texture);
    sfSprite_setOrigin(img_zone->image_sprite,
    (sfVector2f){s_size.x / 2, s_size.y / 2 - 100});
    sfSprite_setTexture(img_zone->image_sprite,
    img_zone->image_texture, sfTrue);
    sfSprite_setPosition(img_zone->image_sprite,
    (sfVector2f){w_size.x / 2, w_size.y / 2});
    return img_zone;
}

void pencil(sfRenderWindow *window,
    image_zone_t *img_zone, sfVector2i mouse_ps)
{
    sfVector2f s_size = sfSprite_getPosition(img_zone->image_sprite);
    int pixel_size = img_zone->pixel_size;
    sfVector2i w_pos = sfRenderWindow_getPosition(window);
    sfVector2i w_mouse_ps = {mouse_ps.x + w_pos.x, mouse_ps.y + w_pos.y};

    for (int i = -pixel_size / 2; i <= pixel_size / 2; i++) {
        for (int j = -pixel_size / 2; j <= pixel_size / 2; j++) {
            sfImage_setPixel(img_zone->image,
            w_mouse_ps.x - s_size.x / 2 + 22 + i,
            w_mouse_ps.y - s_size.y / 2 - 80 + j, img_zone->color);
        }
    }
    sfTexture_updateFromImage(img_zone->image_texture, img_zone->image, 0, 0);
}

static void initializing(all_t *p, sfRenderWindow *window)
{
    p->menu = init_menu((sfVector2f){0, 50}, (sfVector2f){1920, 150}, sfWhite);
    p->file = init_dropdown_menu((sfVector2f){20, 10},
    (sfVector2f){80, 20}, (sfVector2f){40, 40});
    p->file->file_text = add_text("File", 20, (sfVector2f){30, 8}, sfBlack);
    p->file->option1_text = add_text("New", 20, (sfVector2f){20, 25}, sfBlack);
    p->file->option2_text = add_text("Open", 20,
    (sfVector2f){20, 45}, sfBlack);
    p->file->option3_text = add_text("Save", 20,
    (sfVector2f){180, 8}, sfBlack);
    p->palet = init_palet(window);
    p->image_zone = init_image_zone(window, sfWhite);
    p->image_zone->color = sfBlack;
    p->image_zone->pixel_size = 2;
}

static void draw_all(all_t *p, sfRenderWindow *window, sfEvent *event)
{
    sfFloatRect rec;
    sfVector2i mouse_pos;

    if (event->type == sfEvtMouseButtonPressed) {
        change_pixel_color(p->image_zone, p->palet, &event->mouseButton);
        save_image(p->image_zone, p->file, &event->mouseButton);
    }
    if (p->image_zone->is_drawing && sfMouse_isButtonPressed(sfMouseLeft)) {
        rec = sfSprite_getGlobalBounds(p->image_zone->image_sprite);
        mouse_pos = sfMouse_getPositionRenderWindow(window);
        if (sfFloatRect_contains(&rec, mouse_pos.x, mouse_pos.y)) {
            pencil(window, p->image_zone, mouse_pos);
        }
    }
    sfRenderWindow_drawRectangleShape(window, p->menu->menu_rect, NULL);
    draw_palet(window, p->palet);
    draw_options(p->file, window, &event->mouseMove);
    sfRenderWindow_drawText(window, p->file->file_text, NULL);
    sfRenderWindow_drawSprite(window, p->image_zone->image_sprite, NULL);
}

void destroy_all(all_t *p, sfRenderWindow *window)
{
    sfSprite_destroy(p->image_zone->image_sprite);
    sfRectangleShape_destroy(p->menu->menu_rect);
    destroy_palet(p->palet);
    free_options(p->file);
    sfTexture_destroy(p->image_zone->image_texture);
    sfImage_destroy(p->image_zone->image);
    sfRenderWindow_destroy(window);
}

int main(int ac, char **av)
{
    sfVideoMode mode = {1920, 1080, 32};
    sfRenderWindow* window;
    sfEvent event;
    all_t *p;

    window = sfRenderWindow_create(mode, "My Paint", sfResize | sfClose, NULL);
    if (!window)
        return EXIT_FAILURE;
    if (usage(ac, av) == 0)
        return 0;
    initializing(p, window);
    while (sfRenderWindow_isOpen(window)) {
        analyse_events(window, &event, p->image_zone);
        sfRenderWindow_clear(window, sfColor_fromRGB(200, 200, 200));
        draw_all(p, window, &event);
        sfRenderWindow_display(window);
    }
    destroy_all(p, window);
    return EXIT_SUCCESS;
}
