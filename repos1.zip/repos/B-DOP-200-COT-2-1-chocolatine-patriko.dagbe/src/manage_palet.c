/*
** EPITECH PROJECT, 2023
** B-MUL-200-COT-2-1-mypaint-patriko.dagbe
** File description:
** manage_palet.c
*/

#include "../include/paint.h"

static void cut_init_palet(palet_t *palet)
{
    palet->c5 = init_button((sfVector2f){1400, 115}, (sfVector2f){40, 40},
    sfColor_fromRGB(255, 255, 0));
    palet->c6 = init_button((sfVector2f){1350, 115}, (sfVector2f){40, 40},
    sfColor_fromRGB(253, 108, 158));
    palet->c7 = init_button((sfVector2f){1300, 115}, (sfVector2f){40, 40},
    sfColor_fromRGB(0, 0, 255));
    palet->c8 = init_button((sfVector2f){1250, 115}, (sfVector2f){40, 40},
    sfColor_fromRGB(100, 30, 30));
}

palet_t *init_palet(sfRenderWindow *window)
{
    palet_t *palet = malloc(sizeof(palet_t));

    palet->eraser = init_button((sfVector2f){1600, 95}, (sfVector2f){40, 40},
    sfColor_fromRGB(255, 255, 255));
    palet->pen_tex = sfTexture_createFromFile("sprites/pencil.png", NULL);
    palet->pen_sprite = sfSprite_create();
    palet->era_tex = sfTexture_createFromFile("sprites/eraser.png", NULL);
    palet->eraser_sprite = sfSprite_create();
    palet->c1 = init_button((sfVector2f){1400, 70}, (sfVector2f){40, 40},
    sfColor_fromRGB(255, 0, 0));
    palet->c2 = init_button((sfVector2f){1350, 70}, (sfVector2f){40, 40},
    sfColor_fromRGB(255, 55, 250));
    palet->c3 = init_button((sfVector2f){1300, 70}, (sfVector2f){40, 40},
    sfColor_fromRGB(135, 206, 235));
    palet->c4 = init_button((sfVector2f){1250, 70}, (sfVector2f){40, 40},
    sfColor_fromRGB(0, 255, 0));
    cut_init_palet(palet);
    return palet;
}

void draw_palet(sfRenderWindow *window, palet_t *palet)
{
    sfRenderWindow_drawRectangleShape(window, palet->eraser->rect, NULL);
    sfSprite_setPosition(palet->pen_sprite, (sfVector2f){1315, 160});
    sfSprite_setScale(palet->pen_sprite, (sfVector2f){0.2, 0.2});
    sfSprite_setTexture(palet->pen_sprite, palet->pen_tex, sfTrue);
    sfRenderWindow_drawSprite(window, palet->pen_sprite, NULL);
    sfSprite_setPosition(palet->eraser_sprite, (sfVector2f){1600, 95});
    sfSprite_setScale(palet->eraser_sprite, (sfVector2f){0.2, 0.2});
    sfSprite_setTexture(palet->eraser_sprite, palet->era_tex, sfTrue);
    sfRenderWindow_drawSprite(window, palet->eraser_sprite, NULL);
    sfRenderWindow_drawRectangleShape(window, palet->c1->rect, NULL);
    sfRenderWindow_drawRectangleShape(window, palet->c2->rect, NULL);
    sfRenderWindow_drawRectangleShape(window, palet->c3->rect, NULL);
    sfRenderWindow_drawRectangleShape(window, palet->c4->rect, NULL);
    sfRenderWindow_drawRectangleShape(window, palet->c5->rect, NULL);
    sfRenderWindow_drawRectangleShape(window, palet->c6->rect, NULL);
    sfRenderWindow_drawRectangleShape(window, palet->c7->rect, NULL);
    sfRenderWindow_drawRectangleShape(window, palet->c8->rect, NULL);
}

void free_palet(palet_t *palet)
{
    free(palet->eraser);
    free(palet->c1);
    free(palet->c2);
    free(palet->c3);
    free(palet->c4);
    free(palet->c5);
    free(palet->c6);
    free(palet->c7);
    free(palet->c8);
    free(palet);
}

void destroy_palet(palet_t *palet)
{
    sfRectangleShape_destroy(palet->eraser->rect);
    sfSprite_destroy(palet->pen_sprite);
    sfTexture_destroy(palet->pen_tex);
    sfRectangleShape_destroy(palet->c1->rect);
    sfRectangleShape_destroy(palet->c2->rect);
    sfRectangleShape_destroy(palet->c3->rect);
    sfRectangleShape_destroy(palet->c4->rect);
    sfRectangleShape_destroy(palet->c5->rect);
    sfRectangleShape_destroy(palet->c6->rect);
    sfRectangleShape_destroy(palet->c7->rect);
    sfRectangleShape_destroy(palet->c8->rect);
    free_palet(palet);
}

static void cut_change_pixel_color(image_zone_t *image_zone,
    palet_t *palet, sfMouseButtonEvent *evt)
{
    if (palet->c4->is_clicked(palet->c4, evt)) {
        image_zone->pixel_size = 4;
        image_zone->color = sfColor_fromRGB(0, 255, 0);
    }
    if (palet->c5->is_clicked(palet->c5, evt)) {
        image_zone->pixel_size = 4;
        image_zone->color = sfColor_fromRGB(255, 255, 0);
    }
    if (palet->c6->is_clicked(palet->c6, evt)) {
        image_zone->pixel_size = 4;
        image_zone->color = sfColor_fromRGB(253, 108, 158);
    }
    if (palet->c7->is_clicked(palet->c7, evt)) {
        image_zone->pixel_size = 4;
        image_zone->color = sfColor_fromRGB(0, 0, 255);
    }
    if (palet->c8->is_clicked(palet->c8, evt)) {
        image_zone->pixel_size = 4;
        image_zone->color = sfColor_fromRGB(100, 30, 30);
    }
}

void change_pixel_color(image_zone_t *image_zone,
    palet_t *palet, sfMouseButtonEvent *evt)
{
    if (palet->eraser->is_clicked(palet->eraser, evt)) {
        image_zone->color = sfColor_fromRGB(255, 255, 255);
        image_zone->pixel_size = 30;
    }
    if (palet->c1->is_clicked(palet->c1, evt)) {
        image_zone->pixel_size = 4;
        image_zone->color = sfColor_fromRGB(255, 0, 0);
    }
    if (palet->c2->is_clicked(palet->c2, evt)) {
        image_zone->pixel_size = 4;
        image_zone->color = sfColor_fromRGB(255, 55, 250);
    }
    if (palet->c3->is_clicked(palet->c3, evt)) {
        image_zone->pixel_size = 4;
        image_zone->color = sfColor_fromRGB(135, 206, 235);
    }
    cut_change_pixel_color(image_zone, palet, evt);
}
