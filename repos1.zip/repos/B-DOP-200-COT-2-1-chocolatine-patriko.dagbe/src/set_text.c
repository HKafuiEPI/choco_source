/*
** EPITECH PROJECT, 2023
** B-MUL-200-COT-2-1-mypaint-patriko.dagbe
** File description:
** set_text.c
*/

#include "../include/paint.h"

sfText *add_text(char *string, int size, sfVector2f pos, sfColor color)
{
    sfFont *font = sfFont_createFromFile("polices/Astonia.ttf");
    sfText *fileText = sfText_create();
    sfFloatRect fileBounds;

    sfText_setString(fileText, string);
    sfText_setFont(fileText, font);
    sfText_setCharacterSize(fileText, size);
    sfText_setFillColor(fileText, color);
    fileBounds = sfText_getLocalBounds(fileText);
    sfText_setPosition(fileText, pos);
    return fileText;
}
