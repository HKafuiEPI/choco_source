/*
** EPITECH PROJECT, 2023
** B-MUL-200-COT-2-1-mypaint-patriko.dagbe
** File description:
** is_clicked.c
*/

#include "../include/paint.h"

sfBool is_clicked(button_t *button, sfMouseButtonEvent *evt)
{
    sfFloatRect float_rect = sfRectangleShape_getGlobalBounds(button->rect);

    if (sfFloatRect_contains(&float_rect, evt->x, evt->y) &&
    evt->type == sfEvtMouseButtonPressed)
        return sfTrue;
    return sfFalse;
}

sfBool is_hover(button_t *button, sfMouseMoveEvent *evt)
{
    sfFloatRect float_rect = sfRectangleShape_getGlobalBounds(button->rect);

    if (sfFloatRect_contains(&float_rect, evt->x, evt->y))
        return sfTrue;
    return sfFalse;
}
