/*
** EPITECH PROJECT, 2023
** B-MUL-200-COT-2-1-mypaint-patriko.dagbe
** File description:
** file_button.c
*/

#include "../include/paint.h"
#include "../include/lib.h"

dropdown_menu_t *init_dropdown_menu(sfVector2f position,
    sfVector2f menu_size, sfVector2f option_size)
{
    dropdown_menu_t *menu = malloc(sizeof(dropdown_menu_t));

    if (!menu)
        return NULL;
    menu->color = sfColor_fromRGB(135, 206, 235);
    menu->position = position;
    menu->size = menu_size;
    menu->file = init_button(menu->position, menu->size, menu->color);
    menu->position = (sfVector2f){menu->position.x,
    menu->position.y + menu->position.y + 10};
    menu->option1_rect = init_button(menu->position, menu->size, menu->color);
    menu->position = (sfVector2f){menu->position.x,
    menu->position.y + menu->position.y - 10};
    menu->option2_rect = init_button(menu->position, menu_size, menu->color);
    menu->position = (sfVector2f){menu->position.x + 150,
    menu->position.y - 40};
    menu->option3_rect = init_button(menu->position, menu_size, menu->color);
    return menu;
}

void draw_options(dropdown_menu_t *menu,
    sfRenderWindow *window, sfMouseMoveEvent *evt)
{
    sfRenderWindow_drawRectangleShape(window, menu->file->rect, NULL);
    sfRenderWindow_drawRectangleShape(window,
    menu->option3_rect->rect, NULL);
    sfRenderWindow_drawText(window, menu->option3_text, NULL);
    if (menu->file->is_hover(menu->file, evt)) {
        menu->is_open = sfTrue;
        sfRenderWindow_drawRectangleShape(window,
        menu->option1_rect->rect, NULL);
        sfRenderWindow_drawText(window, menu->option1_text, NULL);
        sfRenderWindow_drawRectangleShape(window,
        menu->option2_rect->rect, NULL);
        sfRenderWindow_drawText(window, menu->option2_text, NULL);
    }
}

void free_options(dropdown_menu_t *menu)
{
    sfRectangleShape_destroy(menu->file->rect);
    sfText_destroy(menu->option1_text);
    sfRectangleShape_destroy(menu->option1_rect->rect);
    sfText_destroy(menu->option2_text);
    sfRectangleShape_destroy(menu->option2_rect->rect);
    sfText_destroy(menu->option3_text);
    sfRectangleShape_destroy(menu->option3_rect->rect);
    free(menu->option1_rect);
    free(menu->option2_rect);
    free(menu->option3_rect);
    free(menu);
}

void save_image(image_zone_t *img_zone,
    dropdown_menu_t *menu, sfMouseButtonEvent *evt)
{
    if (menu->option3_rect->is_clicked(menu->option3_rect, evt)) {
        sfImage_saveToFile(img_zone->image, "image.png");
    }
}
