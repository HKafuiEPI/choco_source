/*
** EPITECH PROJECT, 2023
** B-MUL-200-COT-2-1-mypaint-patriko.dagbe
** File description:
** analyse_events.c
*/

#include "../include/paint.h"
#include "../include/lib.h"

void analyse_events(sfRenderWindow *window, sfEvent *event,
    image_zone_t *img_zone)
{
    while (sfRenderWindow_pollEvent(window, event)) {
        if (event->type == sfEvtClosed)
            sfRenderWindow_close(window);
        if (event->type == sfEvtMouseButtonPressed &&
        event->mouseButton.button == sfMouseLeft) {
            img_zone->is_drawing = sfTrue;
            img_zone->prev_mouse_pos = (sfVector2f){event->mouseButton.x,
            event->mouseButton.y};
        }
        if (event->type == sfEvtMouseButtonReleased &&
        event->mouseButton.button == sfMouseLeft)
            img_zone->is_drawing = sfFalse;
    }
}
