/*
** EPITECH PROJECT, 2024
** B-MUL-200-COT-2-1-mypaint-patriko.dagbe
** File description:
** tests
*/
#include "../include/paint.h"
#include <string.h>
Test(usage, usage)
{
    int argc = 2;
    char *argv[] = {"Juan", "-h"};
    int result = usage(argc, argv);
}

Test(usage, usage_er)
{
    int argc = 2;
    char *argv[] = {"Juan", "l", NULL};
    int result = usage(argc, argv);
}

Test(usage, usage_err)
{
    int argc = 2;
    char **argv = malloc(sizeof(char*) * 20);
    argv[1] = malloc(sizeof(char) * 20);
    argv[1][0] = '-';
    argv[1][1] = '-';
    int result = usage(argc, argv);
    free(argv[1]);
    free(argv);
}

Test(usage, usag_err)
{
    int argc = 3;
    char **argv = malloc(sizeof(char*) * 20);
    argv[1] = malloc(sizeof(char) * 20);
    argv[1][0] = '-';
    argv[1][1] = '-';
    int result = usage(argc, argv);
    free(argv[1]);
    free(argv);
}

Test(usage, usage_errr)
{
    int argc = 2;
    char *argv[] = {"-", "h"};
    int result = usage(argc, argv);
}