/*
** EPITECH PROJECT, 2023
** my_hunter
** File description:
** my_hunter
*/

#ifndef MY_HUNTER_H_
    #define MY_HUNTER_H_
    #include <sys/types.h>
    #include <dirent.h>
    #include <unistd.h>
    #include <sys/stat.h>
    #include <pwd.h>
    #include <stdlib.h>
    #include <math.h>
    #include <fcntl.h>
    #include <SFML/Graphics.h>
    #include <stdlib.h>
    #include <SFML/Window/Export.h>
    #include <SFML/Window/Export.h>
    #include <SFML/Window/Export.h>
    #include <SFML/Window/Joystick.h>
    #include <SFML/Window/Keyboard.h>
    #include <SFML/Window/Mouse.h>
    #include <SFML/Window/Sensor.h>
    #include <SFML/Window/Types.h>
    #include <SFML/System/Vector2.h>
    #include <SFML/System/Export.h>
    #include <SFML/System/Time.h>
    #include <SFML/System/Types.h>
    #include <SFML/Config.h>
    #include <time.h>
    #include <stdio.h>
    #include <math.h>
    #include <SFML/Audio/Export.h>
    #include <SFML/Audio/SoundStatus.h>
    #include <SFML/Audio/Types.h>
    #include <SFML/System/InputStream.h>
    #include <SFML/System/Vector3.h>
    #include <stddef.h>
    #include <SFML/Config.h>
    #include <criterion/criterion.h>
    #include <criterion/redirect.h>
    #include "lib.h"

enum e_gui_state {
    NONE = 0,
    HOVER,
    PRESSED,
    RELEASED
};

// La structure d'un button

typedef struct button_s {
    sfRectangleShape *rect;
    sfBool (*is_clicked)(struct button_s *, sfMouseButtonEvent *);
    sfBool (*is_hover)(struct button_s *, sfMouseMoveEvent *);
} button_t;

typedef struct file {
    const char *text;
    button_t *file_button;
} file_t;

typedef struct edit {
    const char *text;
    button_t *edit_button;
} edit_t;

typedef struct help {
    const char *text;
    button_t *help_button;
} help_t;

typedef struct menu {
    help_t *help;
    edit_t *edit;
    file_t *file;
    sfRectangleShape *menu_rect;
} menu_t;

// La structure du programme my_paint

typedef struct paint {
    sfRenderWindow *window;
    sfEvent *event;
} paint_t;

typedef struct image_zone {
    sfImage *image;
    sfColor color;
    sfTexture *image_texture;
    sfSprite *image_sprite;
    sfBool is_drawing;
    sfVector2f prev_mouse_pos;
    sfVector2f curr_mouse_pos;
    int pixel_size;
} image_zone_t;

typedef struct palet {
    button_t *c1;
    button_t *c2;
    button_t *c3;
    button_t *c4;
    button_t *c5;
    button_t *c6;
    button_t *c7;
    button_t *c8;
    button_t *eraser;
    sfSprite *eraser_sprite;
    sfTexture *era_tex;
    sfSprite *pen_sprite;
    sfTexture *pen_tex;
} palet_t;

typedef struct dropdown_menu {
    button_t *file;
    sfText *file_text;
    button_t *option1_rect;
    sfText *option1_text;
    button_t *option2_rect;
    sfText *option2_text;
    button_t *option3_rect;
    sfText *option3_text;
    sfVector2f position;
    sfVector2f size;
    sfBool is_open;
    sfColor color;
}dropdown_menu_t;


typedef struct my_struct {
    image_zone_t *image_zone;
    menu_t *menu;
    palet_t *palet;
    dropdown_menu_t *file;
} all_t;


// Les événements qui ont rapport avec les buttons

button_t *init_button(sfVector2f position, sfVector2f size, sfColor color);
sfBool is_clicked(button_t *button, sfMouseButtonEvent *evt);
sfBool is_hover(button_t *button, sfMouseMoveEvent *evt);

// analyse des événements du programme

void analyse_events(sfRenderWindow *window,
    sfEvent *event, image_zone_t *image_zone);
void pencil(sfRenderWindow *window,
    image_zone_t *img_zone, sfVector2i mouse_ps);

//manage palet
palet_t *init_palet(sfRenderWindow *window);
void draw_palet(sfRenderWindow *window, palet_t *palet);
void change_pixel_color(image_zone_t *image_zone,
    palet_t *palet, sfMouseButtonEvent *evt);
void free_palet(palet_t *palet);
void destroy_palet(palet_t *palet);

// manage menu_options
int my_putstr(char const *str);
dropdown_menu_t *init_dropdown_menu(sfVector2f position,
    sfVector2f menu_size, sfVector2f option_size);
void draw_options(dropdown_menu_t *menu,
    sfRenderWindow *window, sfMouseMoveEvent *evt);
sfText *add_text(char *string, int size, sfVector2f pos, sfColor color);
void free_options(dropdown_menu_t *menu);

// save images

void save_image(image_zone_t *img_zone,
    dropdown_menu_t *menu, sfMouseButtonEvent *evt);

#endif
