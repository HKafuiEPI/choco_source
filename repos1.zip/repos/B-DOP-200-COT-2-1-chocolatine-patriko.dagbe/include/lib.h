/*
** EPITECH PROJECT, 2023
** B-MUL-200-COT-2-1-mypaint-patriko.dagbe
** File description:
** lib.h
*/

#ifndef LIB_H_
    #define LIB_H_
    #include <stdio.h>
    #include <string.h>
    #include <math.h>
    #include <sys/stat.h>
    #include <unistd.h>
int usage(int ac, char **argv);

int my_puterror(int fd, const char *str, int exit_value);

int my_putstr(char const *str);

int my_strlen(char const *str);

#endif
