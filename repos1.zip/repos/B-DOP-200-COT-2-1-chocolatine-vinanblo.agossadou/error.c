/*
** EPITECH PROJECT, 2024
** deqe
** File description:
** erre
*/

#include <math.h>
#include "my.h"

int check_typenumber(char *str)
{
    if (str == NULL || *str == '\0')
        return 84;

    while (*str != '\0') {
        if (!((*str >= '0' && *str <= '9') || *str == '-'))
            return 84;
        str++;
    }
}

int check_error(int ac, char **av)
{
    if (ac == 1)
        return 0;

    char *valid_functions[] = {"EXP", "COS", "SIN", "COSH", "SINH"};
    int num_functions = 5;
    int valid_function = 0;

    for (int i = 0; i < num_functions; ++i) {
        if (strcmp(av[1], valid_functions[i]) == 0) {
            valid_function = 1;
            break;
        }
    }

    if (!valid_function)
        return 0;

    int num_elements = ac - 2;
    int square_size = sqrt(num_elements);
    if (square_size * square_size != num_elements)
        return 0;
    for (int i = 2; i < ac; ++i) {
        if (!check_typenumber(av[i]))
            return 0;
    }

    return 1;
}

int main(int argc, char **argv)
{
    if (argc == 2) {
    if (argv[1][0] == '-' && argv[1][1] == 'h')
        flag();
    }
    if (check_error(argc, argv) == 0) {
        return (EXIT_FAIL);
    }
}

