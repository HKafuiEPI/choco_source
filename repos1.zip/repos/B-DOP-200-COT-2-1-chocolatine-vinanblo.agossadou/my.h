/*
** EPITECH PROJECT, 2023
** epitech
** File description:
** desc
*/

#ifndef MYH
    #define MYH
    #include <string.h>
    #include <string.h>
    #include <unistd.h>
    #include <stdio.h>
    #include <fcntl.h>
    #include <sys/types.h>
    #include <sys/stat.h>
    #include <stdlib.h>
    #include <math.h>
    #define EXIT_FAIL 84

int my_put_str(char *str);
int flag(void);
int check_error(int ac, char **av);
int check_typenumber(char *str);
int main(int argc, char **argv);
#endif
