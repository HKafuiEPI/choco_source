/*
** EPITECH PROJECT, 2024
** ez
** File description:
** tg
*/

#include <stdio.h>

int flag(void)
{
    printf("USAGE\n");
    printf("    ./108trigo fun a0 a1 a2 ...#br\n");
    printf("DESCRIPTION\n");
    printf("   fun     function to be applied, among at least \"EXP\", \"COS\", \"SIN\", \"COSH\" \n");
    printf("           and \"SINH\" \n");
    printf("   ai      coeficients of the matrix\n");
}

/*int main(int argc, char **argv)
{
    if (argc == 2) {
    if (argv[1][0] == '-' && argv[1][1] == 'h')
        flag();
    }
    }*/
