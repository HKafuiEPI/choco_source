/*
** EPITECH PROJECT, 2023
** xfghv
** File description:
** fthgj
*/
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <math.h>
#include <signal.h>
#include <string.h>
#include <stdlib.h>
#include <string.h>

#ifndef MY_H
    #define MY_H

typedef struct my_struct {
    char **map;
    char *str;
    int i;
    int status;
    char *string;
    char *string2;
    char **map1;
    char **map2;
    char *old;
} mini_t;

#endif
