/*
** EPITECH PROJECT, 2024
** efg
** File description:
** fgh
*/

#include "my.h"

int **matrix(void)
{
    int **tab1;
    int **tab2;
    int **new;
    int i = 0;
    int j = 0;
    int k = 0;

    tab1 = malloc(sizeof(int *) * 2);
    tab2 = malloc(sizeof(int *) * 2);
    for (i = 0; i < 2; i++){
        tab1[i] = malloc(sizeof(int) * 2);
        tab2[i] = malloc(sizeof(int) * 2);
    }
    tab1[0][0] = 0;
    tab1[0][1] = -1;
    tab1[1][0] = -2;
    tab1[1][1] = 3;

    tab2[0][0] = 2;
    tab2[0][1] = 0;
    tab2[1][0] = 1;
    tab2[1][1] = -1;

    new = malloc(sizeof(int *) * 2);
    new[0] = malloc(sizeof(int) * 2);
    new[0][0] = tab1[1][1] * tab2[1][1];

    for (i = 0; i < 2; i++){
        new[i] = malloc(sizeof(int) * 2);
    }
    for(i = 0; i < 2; i++){
        for(j = 0; j < 2; j++){
            new[i][j] = 0;
            for(k = 0; k < 2; k++){
                new[i][j] += tab1[i][k] * tab2[k][j];
            }
        }
    }
    for(i = 0; i < 2; i++){
        for(j = 0; j < 2; j++) {
            printf("%d\t", new[i][j]);
        }
        printf("\n");
    }
    return new;
}

int matrice_a_la_puissance(char **matrix, int n)
{
    int **etoiles2;
    int i = 0;

    etoiles2 = malloc(sizeof(int *) * 3);
    for (i = 0; i < 3; i++){
        etoiles2[i] = malloc(sizeof(int) * 3);
    }
    return 0;
}

int main(void)
{
    matrix();
    return 0;
}
