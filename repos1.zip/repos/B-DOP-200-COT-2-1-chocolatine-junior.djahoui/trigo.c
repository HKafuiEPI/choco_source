/*
** EPITECH PROJECT, 2024
** wedf
** File description:
** dv
*/

#include "my.h"

int *recup_in_int(int argc, char **argv)
{
    int j = 0;
    int i = 0;
    int *tab;

    tab = malloc(sizeof(int) * argc);
    for (i = 1; argv[i] != NULL; i++){
        tab[j] = atoi(argv[i]);
        //printf("%d\n", tab[j]);
        j++;
    }
    return tab;
}

int get_square_line(int argc)
{
    int a;
    int b;
    double c;

    a = argc - 2;
    b = sqrt(a);
    c = sqrt(a);
    if (c == b)
        return b;
    return 1;
}

int **double_int_tab(int *tab, int b)
{
int i;
int j;
int l = 0;
int **str;

str = malloc(sizeof(int *) * b);
    for (i = 0; i < b; i++){
        str[i] = malloc(sizeof(int) * b);
        for (j = 0; j < b && tab[l] != '\0'; j++, l++){
            str[i][j] = tab[l];
        }
    }
    return str;
}

int errors(int argc, char **argv)
{
    int i = 0;
    int j = 0;

    for (i = 2; argv[i] != NULL; i++){
        for (j = 0; argv[i][j] != '\0'; j++){
            if (argv[i][j] < '0' || argv[i][j] > '9'){
                return 1;
            }
        }
    }
    return 0;
}
int aincrad(int argc, char **argv)
{
    int *tab;
    int j = 0;

   tab = recup_in_int(argc, argv);
   j = get_square_line(argc);
    double_int_tab(tab, j);
    return 0;
}

int main(int argc, char **argv)
{
    if (argc == 1){
        return 84;
    }
    if (strcmp("COS", argv[1]) == 1 &&
        strcmp("SIN", argv[1]) == 1 && strcmp("SINH", argv[1]) == 1 &&
        strcmp("COSH", argv[1]) == 1){
            return 84;
    }
    if (get_square_line(argc) == 1){
        return 84;
    }
    if (errors(argc, argv) == 1){
        return 84;
    }
    //aincrad(argc, argv);
    return 0;
}
