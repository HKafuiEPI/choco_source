#!/bin/bash

for file in $(find . -name "*.c"); do
    style-checker "$file" 2>> coding-style-reports.log
done

if [ -s coding-style-reports.log ]; then
    echo "Style errors found:"
    cat coding-style-reports.log
    exit 1
fi

exit 0
