/*
** EPITECH PROJECT, 2024
** lkj
** File description:
** hjk
*/
#include <stdio.h>
#include "../include/utils.h"


int main(void)
{
    int c = 3;
    int b = 5;
    int a = 0;

    a = sum(c, b);
    printf("%d\n", a);
}
