/*
** EPITECH PROJECT, 2024
** jbhgfg
** File description:
** kjhg
*/
#include "../include/utils.h"
int sum(int a, int b)
{
    int c = 0;

    c = a + b;
    return c;
}
