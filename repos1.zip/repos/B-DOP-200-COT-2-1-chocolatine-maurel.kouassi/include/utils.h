/*
** EPITECH PROJECT, 2023
** B-DOP-200-BDX-2-1-chocolatine-elliot.masina
** File description:
** utils
*/

#ifndef UTILS_H_
    #define UTILS_H_
int sum(int a, int b);
#endif
