/*
** EPITECH PROJECT, 2023
** B-DOP-200-BDX-2-1-chocolatine-elliot.masina
** File description:
** test
*/

#include <criterion/criterion.h>
#include <criterion/redirect.h>

#include "utils.h"

/*Test(summary, sum_return_value)
{
    int a = 2;
    int b = 3;

    cr_assert(sum(a, b) == 5);
}*/
