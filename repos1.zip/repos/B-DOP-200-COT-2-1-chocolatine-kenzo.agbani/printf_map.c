/*
** EPITECH PROJECT, 2023
** my_sokoban
** File description:
** sokoban game
*/
#include "mysokoban.h"

char **print_m(char **str)
{
    int i = 0;

    for (i = 0; str[i] != NULL; i++) {
        printw(str[i]);
        printw("\n");
        refresh();
    }
}
