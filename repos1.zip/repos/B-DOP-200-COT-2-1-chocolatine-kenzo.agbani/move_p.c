/*
** EPITECH PROJECT, 2023
** my_sokoban
** File description:
** sokoban game
*/
#include "mysokoban.h"

char **mov_up(player_t pos, char **str)
{
    if (str[pos.y - 1][pos.x] == 'X' && str[pos.y - 2][pos.x] == 'O') {
        str[pos.y][pos.x] = ' ';
        str[pos.y - 1][pos.x] = 'P';
        str[pos.y - 2][pos.x] = 'X';
        return str;
    }
    if (str[pos.y - 1][pos.x] == ' ' || str[pos.y - 1][pos.x] == 'O') {
        str[pos.y][pos.x] = ' ';
        str[pos.y - 1][pos.x] = 'P';
    }
    if (str[pos.y - 1][pos.x] == 'X' &&
    str[pos.y - 2][pos.x] == ' ') {
        str[pos.y][pos.x] = ' ';
        str[pos.y - 2][pos.x] = 'X';
        str[pos.y - 1][pos.x] = 'P';
    }
    return str;
}

char **mov_left(player_t pos, char **str)
{
    if (str[pos.y][pos.x - 1] == 'X' && str[pos.y][pos.x - 2] == 'O') {
        str[pos.y][pos.x] = ' ';
        str[pos.y][pos.x - 1] = 'P';
        str[pos.y][pos.x - 2] = 'X';
        return str;
    }
    if (str[pos.y][pos.x - 1] == ' ' || str[pos.y][pos.x - 1] == 'O') {
        str[pos.y][pos.x] = ' ';
        str[pos.y][pos.x - 1] = 'P';
    }
    if (str[pos.y][pos.x - 1] == 'X' &&
    str[pos.y][pos.x - 2] == ' ') {
        str[pos.y][pos.x] = ' ';
        str[pos.y][pos.x - 2] = 'X';
        str[pos.y][pos.x - 1] = 'P';
    }
    return str;
}

char **mov_right(player_t pos, char **str)
{
    if (str[pos.y][pos.x + 1] == 'X' && str[pos.y][pos.x + 2] == 'O') {
        str[pos.y][pos.x] = ' ';
        str[pos.y][pos.x + 1] = 'P';
        str[pos.y][pos.x + 2] = 'X';
        return str;
    }
    if (str[pos.y][pos.x + 1] == ' ' || str[pos.y][pos.x + 1] == 'O') {
        str[pos.y][pos.x] = ' ';
        str[pos.y][pos.x + 1] = 'P';
    }
    if (str[pos.y][pos.x + 1] == 'X' &&
    str[pos.y][pos.x + 2] == ' ') {
        str[pos.y][pos.x] = ' ';
        str[pos.y][pos.x + 2] = 'X';
        str[pos.y][pos.x + 1] = 'P';
    }
    return str;
}

char **mov_down(player_t pos, char **str)
{
    if (str[pos.y + 1][pos.x] == 'X' && str[pos.y + 2][pos.x] == 'O') {
        str[pos.y][pos.x] = ' ';
        str[pos.y + 1][pos.x] = 'P';
        str[pos.y + 2][pos.x] = 'X';
        return str;
    }
    if (str[pos.y + 1][pos.x] == ' ' || str[pos.y + 1][pos.x] == 'O') {
        str[pos.y][pos.x] = ' ';
        str[pos.y + 1][pos.x] = 'P';
    }
    if (str[pos.y + 1][pos.x] == 'X' &&
    str[pos.y + 2][pos.x] == ' ') {
        str[pos.y][pos.x] = ' ';
        str[pos.y + 2][pos.x] = 'X';
        str[pos.y + 1][pos.x] = 'P';
    }
    return str;
}
