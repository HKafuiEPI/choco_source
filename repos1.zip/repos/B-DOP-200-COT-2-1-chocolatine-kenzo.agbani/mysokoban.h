/*
** EPITECH PROJECT, 2023
** my_sokoban.h
** File description:
** contains the prototypes of all the functions
*/
#ifndef MY_SOKOBAN_H_
    #define MY_SOKOBAN_H_
    #include <unistd.h>
    #include <stdio.h>
    #include <stdarg.h>
    #include <stdlib.h>
    #include <fcntl.h>
    #include <sys/stat.h>
    #include <ncurses.h>

typedef struct player {
    int x;
    int y;
}player_t;

char **my_str_to_word_array(char const *hey);
char *open_file(char const *filepath);
int fline(int i, char *str);
player_t find_player(char **str);
char **print_m(char **str);
char **mov_up(player_t pos, char **str);
char **mov_left(player_t pos, char **str);
char **mov_right(player_t pos, char **str);
char **mov_down(player_t pos, char **str);
int error(int ac, char **av);
void gang(void);
#endif
