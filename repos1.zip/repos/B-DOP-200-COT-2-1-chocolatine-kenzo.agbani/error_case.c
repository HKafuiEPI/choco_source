/*
** EPITECH PROJECT, 2023
** my_sokoban
** File description:
** sokoban game
*/
#include "mysokoban.h"

int check(char **av)
{
    int i = 0;
    int p = 0;
    int x = 0;
    int o = 0;
    char *str = open_file(av[1]);

    for (i = 0; str[i] != '\0'; i++) {
        if (str[i] != '#' && str[i] != ' ' && str[i] != 'P'
        && str[i] != 'X' && str[i] != 'O' && str[i] != '\n')
            return 84;
        if (str[i] == 'P')
            p++;
        if (str[i] == 'O')
            o++;
        if (str[i] == 'X')
            x++;
    }
    if (p != 1 || o != x || x < 1 || o < 1)
        return 84;
}

int error(int ac, char **av)
{
    int e = 0;

    if (ac != 2)
        return 84;
    if (av[1] == NULL)
        return 84;
    if (ac == 2 && *av[1] == '-' && av[1][1] == 'h') {
        gang();
        return 7;
    }
    e = check(av);
    if (e == 84)
        return 84;
}
