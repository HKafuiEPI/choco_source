/*
** EPITECH PROJECT, 2023
** my_str_to_word_array
** File description:
** splits strings into words
*/
#include "mysokoban.h"

int count_line(char const *str)
{
    int a = 0;
    int i = 0;

    while (str[i] != '\0') {
        if (str[i] == '\n')
            a++;
    i++;
    }
    return (a);
}

int btoa(int a, int b)
{
    if (b < a)
        b = a;
    return b;
}

int count_column(char const *str)
{
    int a;
    int b = 0;
    int i;

    for (i = 0; str[i] != '\0'; i++) {
        a = 0;
        while (str[i] != '\n') {
            a++;
            b = btoa(a, b);
            i++;
        }
    }
    return b;
}

char **allow(int a, int b)
{
    int i;
    char **tb = malloc(sizeof(char *) * (a));

    for (i = 0; i < a; i++) {
        tb[i] = malloc(sizeof(char) * (b + 1));
    }
    return tb;
}

char **my_str_to_word_array(char const *hey)
{
    char *str = open_file(hey);
    int a = count_line(str);
    int b = count_column(str);
    int i = 0;
    char **tb = allow(a, b);

    for (b = 0; str[i] != '\0'; b++) {
        a = 0;
        while (str[i] != '\n') {
            tb[b][a] = str[i];
            i++;
            a++;
        }
        if (str[i] == '\n')
            tb[b][a] = '\0';
        i++;
        }
    tb[b] = NULL;
    return tb;
}
