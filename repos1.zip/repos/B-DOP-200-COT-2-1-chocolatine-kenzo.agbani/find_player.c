/*
** EPITECH PROJECT, 2023
** my_sokoban
** File description:
** sokoban game
*/
#include "mysokoban.h"

player_t position(char **str, int i, int a)
{
    player_t pos;

    a = 0;
    while (str[i][a] != '\0') {
        if (str[i][a] == 'P') {
            pos.x = a;
            pos.y = i;
            return pos;
        } else
            a++;
    }
}

player_t find_player(char **str)
{
    int a = 0;
    int i = 0;
    player_t pos;

    for (; str[i] != NULL; i++) {
        pos = position(str, i, a);
        if (pos.x != 0)
            return pos;
    }
}
