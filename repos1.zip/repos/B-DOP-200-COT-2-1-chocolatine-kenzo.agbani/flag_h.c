/*
** EPITECH PROJECT, 2023
** 102ARCHITECT
** File description:
** -h
*/
#include "mysokoban.h"

void my_putchar(char c)
{
    write(1, &c, 1);
}

int my_putstr(char const *str)
{
    int i;

    for (i = 0; str[i] != '\0'; i++) {
        my_putchar(str[i]);
    }
    return i;
}

void gang(void)
{
    my_putstr("USAGE\n    ./my_sokoban map\n\n");
    my_putstr("DESCRIPTION\n    map file representing the warehouse map,");
    my_putstr("containing '#' for walls,\n\t'P' for the player, 'X'");
    my_putstr("for boxes");
    my_putstr(" and 'O' for storage locations.\n");
}
