/*
** EPITECH PROJECT, 2023
** open_file
** File description:
** cp file content in strng
*/
#include "mysokoban.h"

char *open_file(char const *filepath)
{
    struct stat gang;
    int fd = open(filepath, O_RDONLY);
    char *bang;

    if (fd == -1)
        exit;
    stat(filepath, &gang);
    bang = malloc(sizeof(char *) * (gang.st_size + 1));
    read(fd, bang, gang.st_size);
    bang[gang.st_size + 1] = '\0';
    close(fd);
    return bang;
}
