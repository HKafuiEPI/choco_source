/*
** EPITECH PROJECT, 2023
** my_sokoban
** File description:
** sokoban game
*/
#include "mysokoban.h"

char **map_with_o(player_t pos, char **map, char **save)
{
    if (save[pos.y][pos.x] == 'O' && map[pos.y][pos.x] == ' ') {
        map[pos.y][pos.x] = 'O';
    }
    return map;
}

int sokoban(player_t pos, int k, char **str, char **save)
{
    print_m(str);
    k = getch();
    pos = find_player(str);
    if (k == KEY_UP)
        str = mov_up(pos, str);
        str = map_with_o(pos, str, save);
    if (k == KEY_LEFT)
        str = mov_left(pos, str);
        str = map_with_o(pos, str, save);
    if (k == KEY_RIGHT)
        str = mov_right(pos, str);
        str = map_with_o(pos, str, save);
    if (k == KEY_DOWN)
        str = mov_down(pos, str);
        str = map_with_o(pos, str, save);
    return k;
}

int main(int argc, char **argv)
{
    int k = error(argc, argv);
    int i = 0;
    char **tst;
    char **save;
    player_t pos;

    if (k == 84)
        return 84;
    if (k == 7)
        return 0;
    tst = my_str_to_word_array(argv[1]);
    save = my_str_to_word_array(argv[1]);
    initscr();
    keypad(stdscr, TRUE);
    while (k != 113) {
        k = sokoban(pos, k, tst, save);
        clear();
    }
    endwin();
    return 0;
}
