/*
** EPITECH PROJECT, 2023
** my_hunter
** File description:
** my_hunter file
*/

#include "my.h"

void destroyer(tit_t st)
{
    sfSprite_destroy(st.sprite);
    sfTexture_destroy(st.texture);
    sfSprite_destroy(st.spr);
    sfTexture_destroy(st.tex);
    sfSprite_destroy(st.sprite_2);
    sfTexture_destroy(st.texture_2);
    sfClock_destroy(st.clock);
    sfRenderWindow_destroy(st.window);
}

tit_t creator(tit_t st)
{
    st.sprite = sfSprite_create();
    st.sprite_2 = sfSprite_create();
    st.spr = sfSprite_create();
    st.clock = sfClock_create();
    sfSprite_setTexture(st.sprite, st.texture, sfFalse);
    sfSprite_setTexture(st.spr, st.tex, sfFalse);
    sfSprite_setTexture(st.sprite_2, st.texture_2, sfFalse);
    sfRenderWindow_setFramerateLimit(st.window, 30);
    return st;
}

tit_t sheet(tit_t st)
{
    st.time = sfClock_getElapsedTime(st.clock);
    st.seconds = st.time.microseconds / 1000000.0;
    if (st.seconds > 0.2) {
        move_rect(&st, 92, 184);
        sfSprite_setTextureRect(st.sprite_2, st.rect);
        sfSprite_setPosition(st.sprite_2, st.sprite_p);
        sfClock_restart(st.clock);
    }
    return st;
}

void hunter(void)
{
    sfEvent event;
    tit_t st = init();

    st = creator(st);
    if (!st.window);
    while (sfRenderWindow_isOpen(st.window)) {
        while (sfRenderWindow_pollEvent(st.window, &event))
            analyse_events(st, event);
        st = sheet(st);
        st.sprite_p = killer(st, event);
        if (st.sprite_p.x > st.mode.width)
            st.sprite_p.x = 0;
        else
            st.sprite_p.x += 25;
        drawer(st);
    }
    destroyer(st);
}

int main(int ac, char **av)
{
    tit_t st;

    if (ac == 2 && av[1][0] == '-' && av[1][1] == 'h')
        usage();
    else if (ac == 1) {
        hunter();
        return EXIT_SUCCESS;
    }
    return 0;
}
