/*
** EPITECH PROJECT, 2023
** tools
** File description:
** tools file
*/

#include "my.h"

void my_putchar(char c)
{
    write(1, &c, 1);
}

int my_putstr(char const *str)
{
    int i = 0;

    while (str[i] != 0) {
        my_putchar(str[i]);
        i++;
    }
    return 0;
}

int my_put_nbr(int nb)
{
    int i = 1;

    if (nb < 0) {
        my_putchar('-');
        nb = - nb;
    }
    while ((nb / i) > 9)
        i = i * 10;
    while (i >= 1) {
        my_putchar((nb / i) + '0');
        nb = nb % i;
        i = i / 10;
    }
    return 0;
}

void usage(void)
{
    my_putstr("USAGE\n");
    my_putstr("    ./my_hunter\n\n");
    my_putstr("DESCRIPTION\n");
    my_putstr("Duck Hunt[a] is a 1984 light gun shooter video game");
    my_putstr(" developed and published by Nintendo for the Nintendo");
    my_putstr(" Entertainment System (NES) video game console and");
    my_putstr(" the Nintendo Vs. System arcade hardware.\n");
    my_putstr("But now it's time for a replica of this landmark game, in the");
    my_putstr(" form of a CSFML and C language project.\n");
    my_putstr("Here, a red-hooded ghost wanders around");
    my_putstr(" an abandoned lighthouse.\n");
    my_putstr("The ghost is very prankish and tends to end");
    my_putstr(" up anywhere on your screen.\n\n");
    my_putstr("Pay attention!!!\n\n                  #Paladin des mots\n\n\n");
}

void drawer(tit_t st)
{
    sfRenderWindow_clear(st.window, sfBlack);
    sfRenderWindow_drawSprite(st.window, st.sprite, NULL);
    sfRenderWindow_drawSprite(st.window, st.spr, NULL);
    sfRenderWindow_drawSprite(st.window, st.sprite_2, NULL);
    sfRenderWindow_display(st.window);
}
