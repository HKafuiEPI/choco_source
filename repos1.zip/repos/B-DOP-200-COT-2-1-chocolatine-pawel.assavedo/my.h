/*
** EPITECH PROJECT, 2023
** my.h
** File description:
** my.h file of my_hunter
*/

#ifndef MY_H
    #define MY_H
    #include <SFML/Graphics.h>
    #include <unistd.h>
    #include <stdlib.h>
    #include <time.h>
    #include <stdio.h>
    #include <SFML/System.h>
    #include <SFML/Graphics.h>

typedef struct tit {
    sfVideoMode mode;
    sfRenderWindow* window;
    sfTexture* texture;
    sfSprite* sprite;
    sfTexture* texture_2;
    sfSprite* sprite_2;
    sfClock *clock;
    sfTime time;
    float seconds;
    sfVector2f sprite_p;
    sfIntRect rect;
    sfSprite* spr;
    sfTexture* tex;
} tit_t;

tit_t init(void);
void manage_mouse_click(sfMouseButtonEvent event);
void analyse_events(tit_t st, sfEvent event);
void move_rect(tit_t *st, int lar, int max_value);
sfVector2f killer(tit_t st, sfEvent event);
void drawer(tit_t st);
void destroyer(tit_t st);
tit_t sheet(tit_t st);
void my_putchar(char c);
int my_putstr(char const *str);
int my_put_nbr(int nb);
void hunter(void);
void usage(void);
#endif
