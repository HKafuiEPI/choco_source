/*
** EPITECH PROJECT, 2023
** other
** File description:
** other file
*/

#include "my.h"

tit_t init(void)
{
    tit_t st;

    st.mode.width = 1280;
    st.mode.height = 720;
    st.mode.bitsPerPixel = 90;
    st.window = sfRenderWindow_create(st.mode, "HH", sfResize | sfClose, NULL);
    st.texture = sfTexture_createFromFile("cath.png", NULL);
    st.texture_2 = sfTexture_createFromFile("ghost.png", NULL);
    st.tex = sfTexture_createFromFile("tool.png", NULL);
    st.rect.top = 276;
    st.rect.left = 92;
    st.rect.width = 89;
    st.rect.height = 92;
    return st;
}

void manage_mouse_click(sfMouseButtonEvent event)
{
    if (event.type == sfEvtMouseButtonPressed) {
        my_putstr("x = ");
        my_put_nbr(event.x);
        my_putchar('\n');
        my_putstr("y = ");
        my_put_nbr(event.y);
        my_putchar('\n');
    }
}

void analyse_events(tit_t st, sfEvent event)
{
    if (event.type == sfEvtClosed)
        sfRenderWindow_close(st.window);
    manage_mouse_click(event.mouseButton);
}

void move_rect(tit_t *st, int lar, int max_value)
{
    if (st->rect.left < max_value)
        st->rect.left = st->rect.left + lar;
    else
        st->rect.left = 0;
}

sfVector2f killer(tit_t st, sfEvent event)
{
    sfVector2i c = sfMouse_getPositionRenderWindow(st.window);
    sfVector2f r = sfSprite_getPosition(st.sprite_2);

    if (c.x >= r.x && c.x <= r.x + 89 && c.y >= r.y && c.y <= r.y + 92)
        if (event.mouseButton.type == sfEvtMouseButtonPressed) {
            r.x = rand() % (1280 - 92);
            r.y = rand() % (720 - 92);
            sfSprite_setPosition(st.sprite_2, r);
        }
    return r;
}
