/*
** EPITECH PROJECT, 2024
** my.h
** File description:
** my
*/

#ifndef MY_H
    #define MY_H
    #include <stdio.h>
    #include <unistd.h>
    #include <stdlib.h>

void numb_individual(double n, double k);
void h_flag(void);
int bombyx(int n, int fgen, int final);

#endif /* !MY_H_ */
