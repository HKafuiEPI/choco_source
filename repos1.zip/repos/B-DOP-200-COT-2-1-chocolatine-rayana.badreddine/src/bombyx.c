/*
** EPITECH PROJECT, 2024
** bombyx
** File description:
** bombyx project
*/

#include "../include/my.h"

void numb_individual(double n, double k)
{
    double xi = n;
    int max = 100;
    int i;

    for (i = 1; i <= max; i++) {
        if (xi < 0) {
            printf("%d 0.00\n", i);
        } else {
            printf("%d %.2f\n", i, xi);
            xi = k * xi * ((1000 - xi) / 1000);
        }
    }
}

void reduce_function(double x, double k)
{
    if (x < 0) {
        printf("%.2f 0.00\n", k);
    } else {
        printf("%.2f %.2f\n", k, x);
    }
}

int bombyx(int n, int fgen, int final)
{
    double k;
    double x;

    for (k = 1; k <= 4; k += 0.01) {
        x = n;
        for (int j = 0; j <= fgen; j++) {
            x = k * x * ((1000 - x) / 1000);
        }
        for (int v = fgen; v <= final; v++) {
            reduce_function(x, k);
            x = k * x * ((1000 - x) / 1000);
        }
    }
}
