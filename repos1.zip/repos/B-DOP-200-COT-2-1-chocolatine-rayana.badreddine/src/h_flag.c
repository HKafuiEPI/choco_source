/*
** EPITECH PROJECT, 2024
** h_flag
** File description:
** help option
*/

#include "../include/my.h"

void h_flag(void)
{
    printf("USAGE\n    ./106bombyx n [k | i0 i1]\n");
    printf("\nDESCRIPTION\n    n       number ");
    printf("of first generation individuals\n");
    printf("    k       growth rate from 1 to 4\n");
    printf("    i0      initial generation (included)\n");
    printf("    i1      final generatin (included)\n");
}
