/*
** EPITECH PROJECT, 2024
** main
** File description:
** main
*/

#include "../include/my.h"

int main(int ac, char *av[])
{
    if (ac == 1) {
        return 84;
    }
    if (ac == 3 && atof(av[1]) > 0
    && (atof(av[2]) >= 1 && atof(av[2]) <= 4)) {
        numb_individual(atof(av[1]), atof(av[2]));
        return 0;
    }
    if (ac == 4 && atof(av[1]) > 0) {
        bombyx(atof(av[1]), atoi(av[2]), atoi(av[3]));
        return 0;
    }
    if (ac == 2 && av[1][0] == '-' && av[1][1] == 'h') {
        h_flag();
    } else {
        return 84;
    }
}
