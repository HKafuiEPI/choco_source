/*
** EPITECH PROJECT, 2024
** header_stumper
** File description:
** stumper04
*/

#ifndef MY_INCLUDED
    #define MY_INCLUDED
    #include <stdio.h>
    #include <unistd.h>
    #include <string.h>
    #include <stdlib.h>

void my_putchar(char c);

int my_putstr(char *str);

int us_name_formatter(char *str);

char maj(char a);

char min(char a);

#endif // MY_INCLUDED
