#include <string.h>
#include <stdio.h>
#include <unistd.h>

int my_strlen(const char *str)
{
    int b;

    for (int a = 0; str[a] != '\0'; a++)
        b++;
    return b;
}

int Space(const char *str)
{
    int i;
    int len = my_strlen(str);

    for (i = 0; i < len; i++) {
        if (str[i] == ' ' || str[i] == '\t') {
            return i;
        }
    }
    return -1;
}

int respace(const char *str)
{
    int i;
    int len = my_strlen(str);
     
    for (i = len; i > 0; i--) {
        if (str[i] == ' ' || str[i] == '\t') {
            return (i);
        }
    }
    return -1;
}

/*void Reverse(const char *str, int start, int end)
{
    int i;

    for (i = end; i >= start; i--) {
        write(1, &str[i], 1);
    }
}
*/
void String_space(const char *str, int start, int end)
{
    int i;

    for (i = start; i <= end; i++) {
        if (str[i] != ' ' && str[i] != '\t') {
            write(1, &str[i], 1);
        } else {
            write(1, " ", 1);
        }
    }
}

void String_ro(char *str)
{
    int len = my_strlen(str);
    int s = Space(str);
    int r = respace(str);
   
    if (s == -1) {
        write(1, str, len);
        write(1, "\n", 1);
        return;
    }
    String_space(str, r + 1, len);
    write(1, &str[s], 1);
    String_space(str, 0, s -1);
    write(1, &str[s], 1);
    String_space(str, s + 1, r - 1);
    write(1, "\n", 1);
}

int main(int argc, char **argv)
{
    if (argc != 2) {
        write(1, "\n", 1);
        return 0;
    } else {
        String_ro(argv[1]);
    }
    return 0;
}
