/*
** EPITECH PROJECT, 2024
** my_putstr
** File description:
** used function
*/

#include "my.h"

int my_putstr(char *str)
{
    int a;

    for (a = 0; str[a] != '\0'; a++) {
        my_putchar(str[a]);
    }
    return 0;
}
