/*
** EPITECH PROJECT, 2023
** square
** File description:
** display square
*/
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include "my.h"
#include <string.h>


int cont_line(char *src)
{
    int a = 0;

    for (int i = 0; src[i] != '\0'; i++) {
        if (src[i] == '\n')
            a = a + 1;
    }
    return a;
}

int cont_colun(char *src)
{
    int a = 0;
    int c = 0;

    for (a = 0; src[a] != '\n'; a++) {
    }
    a++;
    for (; src[a] != '\n'; a++) {
        c++;
    }
    return c;
}

char **m_allocation(int a, int b)
{
    int i;
    char **reg;

    reg = malloc(sizeof(char *) * (a));
    for (i = 0; i < a; i++) {
        reg[i] = malloc(sizeof(char) *(b));
    }
    return reg;
}

int fline(char *str)
{
    int i = 0;

    while (str[i] != '\n')
        i++;
    return i;
}

char **my_str_to_word_array(char **filepath)
{
    char *str = fs_cat_500_bytes(filepath[1]);
    int b = cont_line(str);
    int c = cont_colun(str);
    char **reg = m_allocation(b, c);
    int a = fline(str) + 1;

    c = 0;
    for (b = 0; str[a] != '\0'; a++) {
        if (str[a] != '\n' && str[a] != '\0') {
            reg[b][c] = str[a];
            c++;
        }
        if (str[a] == '\n' || str[a] == '\0'){
            reg[b][c] = '\0';
            b = b + 1;
            c = 0;
        }
    }
    reg[b] = NULL;
    return reg;
}
