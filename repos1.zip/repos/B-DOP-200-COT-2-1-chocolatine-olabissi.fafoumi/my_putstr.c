/*
** EPITECH PROJECT, 2023
** my putstr
** File description:
** displays, one by one the characters of a string
*/

#include <unistd.h>
#include "my.h"
int help(char *map, int c, int size)
{
    int b = 1;

    for (b = 1; map[c] != '\0' && b <= size; b++) {
        if (map[c] == 'o')
            return 1;
        c++;
    }
    if ((b - 1) != size)
        return 2;
    return 0;
}

int is_square_of_size(char **map, int line, int col, int size)
{
    int a = 0;
    int b = 1;
    int c = 0;

    for (a = 1; map[line] != NULL && a <= size; a++) {
        c = help(map[line], col, size);
        if (c != 0)
            return 3;
        c = col;
        line ++;
    }
    if ((a - 1) != size)
    return 4;
    return 0;
}

int *biggest_square(char **map, int a, int b, int c)
{
    int size = 0;
    int *tab = malloc(sizeof(int) * 3);

    tab[0] = 0;
    for (; map[a][b] != '\0'; b++) {
        for (size = 0; c == 0; size++)
            c = is_square_of_size(map, a, b, size);
        if ((size - 2) > tab[0]) {
            tab[0] = size - 2;
            tab[1] = a;
            tab[2] = b;
        }
        if (map[a + 1] != NULL && map[a][b + 1] == '\0') {
            a++;
            b = -1;
        }
        c = 0;
    }
    return tab;
}

char *fs_cat_500_bytes(char *filepath)
{
    int yo = open(filepath, O_RDONLY);
    struct stat sizes;
    char *buff;

    stat(filepath, &sizes);
    buff = malloc(sizeof(char) * (sizes.st_size + 1));
    read(yo, buff, sizes.st_size);
    buff[sizes.st_size + 1] = '\0';
    close(yo);
    return buff;
}
