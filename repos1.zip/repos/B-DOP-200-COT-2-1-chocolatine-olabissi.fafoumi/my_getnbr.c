/*
** EPITECH PROJECT, 2023
** getnbr
** File description:
** prendre le nombre uniquement
*/

#include "my.h"
#include <stdio.h>

int my_getnbr(char const *str)
{
    int i = 0;
    int a = 1;
    int n = 0;
    int t;

    while (str[i] >= '0' && str[i] <= '9') {
        t = str[i] - 48;
        n = (n * 10) + t;
        i++;
    }
    return n;
}

char *put(char **av, char *dest, int a, int *c)
{
    int b = 0;

    for (; b < a; b++){
        dest[b] = av[2][(*c)];
        if (av[2][(*c) + 1] == '\0')
            (*c) = -1;
        (*c)++;
    }
    dest[a] = '\0';
    return dest;
}

int generator(char **av)
{
    int b = 0;
    int c = 0;
    int *tab;
    int d = 0;
    int a = my_getnbr(av[1]);
    char **dest = m_allocation(a, a);

    for (; b < a; b++) {
        dest[b] = put(av, dest[b], a, &d);
    }
    dest[a] = NULL;
    tab = biggest_square(dest, 0, 0, 0);
        dest = inserte(tab, dest);
    for (; dest[c] != NULL; c++)
        my_putstr(dest[c]);
    return 0;
}
