/*
** EPITECH PROJECT, 2023
** MY.H
** File description:
**  prototypes of all the functions
*/

#ifndef MY_H
    #define MY_H
    #include <unistd.h>
    #include <sys/types.h>
    #include <dirent.h>
    #include <stdio.h>
    #include <stdlib.h>
    #include <stdlib.h>
    #include <fcntl.h>
    #include <unistd.h>
    #include <stdio.h>
    #include <sys/stat.h>

void my_putchar(char c);
int my_put_nbr(int nb);
void my_putstr(char *str);
int mini_printf(const char *format, ...);
char *my_strcpy(char *dest, char const *src);
int my_strlen(char const *str);
char **my_str_to_word_array(char **str);
char *fs_cat_500_bytes(char *filepath);
char **detecte_square(char **av);
char **display_square(char **reg, int a, int b);
int is_square_of_size(char **map, int line, int col, int square_size);
int *biggest_square(char **map, int nb_rows, int nb_cols, int row);
int my_getnbr(char const *str);
int cont_line(char *src);
char **m_allocation(int a, int b);
int generator(char **av);
char **inserte(int *tab, char **map);
int fline(char *str);
#endif
