/*
** EPITECH PROJECT, 2023
** square
** File description:
** display square
*/
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/stat.h>
#include "my.h"

void my_putstr(char *str)
{
    int i = 0;

    for (; str[i] != '\0'; i++)
        write(1, &str[i], 1);
    my_putchar('\n');
}

char **inserte(int *tab, char **map)
{
    int a = tab[2];
    int b = 0;
    int c = 0;
    int d = tab[1];

    for (; b < tab[0]; b++) {
        for (a = tab[2]; c < tab[0]; c++) {
            map[d][a] = 'x';
            a++;
        }
        c = 0;
        d++;
    }
    return map;
}

int error(char **av)
{
    int a = 0;

    for (a = 0; av[1][a] != '\0'; a++)
        if (av[1][a] < '0' || av[1][a] > '9')
            return 84;
    for (a = 0; av[2][a] != '\0'; a++)
        if (av[2][a] != '.' && av[2][a] != 'o')
            return 84;
    if (a == 0)
        return 84;
    return 0;
}

int error_2(char **av)
{
    char *get;
    int a = open(av[1], O_RDONLY);
    int b = 0;
    int c = 0;

    if (a == -1) {
        close(a);
        return 84;
    }
    get = fs_cat_500_bytes(av[1]);
    b = my_getnbr(get);
    c = cont_line(get);
    if ((b + 1) != c)
        return 84;
    a = fline(get);
    for (; get[a] != '\0'; a++)
        if (get[a] != '.' && get[a] != 'o' && get[a] != '\n')
            return 84;
    return 0;
}

int main(int ac, char **av)
{
    int i = 0;
    char **dest;
    int *tab;

    if (ac < 2 || ac > 3)
        return 84;
    if (ac == 3 && error(av) == 84)
        return 84;
    if (ac == 2 && error_2(av) == 84)
        return 84;
    if (ac == 3) {
        generator(av);
        return 0;
    }
    dest = my_str_to_word_array(av);
        tab = biggest_square(dest, 0, 0, 0);
        dest = inserte(tab, dest);
    for (; dest[i] != NULL; i++)
        my_putstr(dest[i]);
    return 0;
}
