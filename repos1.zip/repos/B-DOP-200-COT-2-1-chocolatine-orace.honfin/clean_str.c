/*
** EPITECH PROJECT, 2024
** clean_str.c
** File description:
** clean
*/
#include <stdio.h>
#include <unistd.h>

char *clean(char *str)
{
    int i = 0;

    if (str[i] == ' ') {
        write(1, "", 1);
    }
    while (str[i] != '\0') {
        if (str[i] != ' ' && str[i] != '\t') {
            write(1, &str[i], 1);
        }
        if (str[i] == ' ' && str[i + 1] != '\0' && str[i + 1] != ' ') {
            write(1, " ", 1);
        }
        i++;
    }
    write(1, "\n", 1);
    return str;
}

int main(int argc, char **argv)
{
    char *str = argv[1];

    if (argc == 2) {
        clean(str);
    } else if (argc == 1) {
        write(1, "\n", 1);
    } else {
        return 84;
    }
}
